import React, { Suspense, createRef, lazy, useRef } from 'react';
import { BrowserRouter, Navigate, Route, Routes, useLocation } from 'react-router-dom';
import { Alert, Spinner } from 'react-bootstrap';
import { CSSTransition, TransitionGroup } from 'react-transition-group';
import './App.css';
import AppLayout from './components/AppLayout';
import { ProductProvider } from './context/ProductContext';
import AddProductPage from './pages/AddProductPage';
import ProductListPage from './pages/ProductListPage';

const ProductDetailPage = lazy(() => import('./pages/ProductDetailPage'));

function AnimatedRoutes() {
  const location = useLocation();
  const nodeRefs = useRef({});

  if (!nodeRefs.current[location.pathname]) {
    nodeRefs.current[location.pathname] = createRef();
  }

  const currentNodeRef = nodeRefs.current[location.pathname];

  return (
    <AppLayout>
      <TransitionGroup component={null}>
        <CSSTransition
          key={location.pathname}
          classNames="route-fade"
          timeout={250}
          unmountOnExit
          nodeRef={currentNodeRef}
        >
          <div ref={currentNodeRef} className="route-wrapper">
            <Routes location={location}>
              <Route path="/" element={<Navigate to="/products" replace />} />
              <Route path="/products" element={<ProductListPage />} />
              <Route path="/products/new" element={<AddProductPage />} />
              <Route
                path="/products/:id"
                element={
                  <Suspense
                    fallback={
                      <div className="text-center py-4">
                        <Spinner animation="border" role="status" />
                      </div>
                    }
                  >
                    <ProductDetailPage />
                  </Suspense>
                }
              />
              <Route path="*" element={<Alert variant="warning">Page not found.</Alert>} />
            </Routes>
          </div>
        </CSSTransition>
      </TransitionGroup>
    </AppLayout>
  );
}

function App() {
  return (
    <ProductProvider>
      <BrowserRouter>
        <AnimatedRoutes />
      </BrowserRouter>
    </ProductProvider>
  );
}

export default App;
