import React, { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react';
import PropTypes from 'prop-types';
import { createProduct, getProducts } from '../services/productService';

const ProductContext = createContext(null);

export function ProductProvider({ children }) {
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  const fetchProducts = useCallback(async () => {
    setLoading(true);
    setError('');
    try {
      const data = await getProducts();
      setProducts(data);
    } catch (err) {
      setError('Failed to load products. Please try again.');
    } finally {
      setLoading(false);
    }
  }, []);

  const addProduct = useCallback(async (productData) => {
    setError('');
    try {
      const createdProduct = await createProduct(productData);
      setProducts((currentProducts) => [...currentProducts, createdProduct]);
      return createdProduct;
    } catch (err) {
      throw new Error('Failed to add product. Please try again.');
    }
  }, []);

  useEffect(() => {
    fetchProducts();
  }, [fetchProducts]);

  const contextValue = useMemo(
    () => ({
      products,
      loading,
      error,
      fetchProducts,
      addProduct,
    }),
    [products, loading, error, fetchProducts, addProduct]
  );

  return <ProductContext.Provider value={contextValue}>{children}</ProductContext.Provider>;
}

ProductProvider.propTypes = {
  children: PropTypes.node.isRequired,
};

export function useProducts() {
  const context = useContext(ProductContext);
  if (!context) {
    throw new Error('useProducts must be used within ProductProvider');
  }
  return context;
}

