import React from 'react';
import { useParams } from 'react-router-dom';
import { Alert, Card, Spinner } from 'react-bootstrap';
import { useProducts } from '../context/ProductContext';

function ProductDetailPage() {
  const { id } = useParams();
  const { products, loading, error } = useProducts();
  const product = products.find((item) => String(item.id) === String(id));
  const numericPrice = Number(product?.price);
  const formattedPrice = Number.isNaN(numericPrice)
    ? 'N/A'
    : new Intl.NumberFormat('en-IN', {
        style: 'currency',
        currency: 'INR',
      }).format(numericPrice);

  if (loading) {
    return (
      <div className="text-center py-4">
        <Spinner animation="border" role="status" />
      </div>
    );
  }

  if (error) {
    return <Alert variant="danger">{error}</Alert>;
  }

  if (!product) {
    return <Alert variant="warning">Product not found.</Alert>;
  }

  return (
    <>
      <h2 className="mb-4">Product Detail</h2>
      <Card>
        <Card.Body>
          <Card.Title>{product.name}</Card.Title>
          <Card.Subtitle className="mb-3 text-muted">{product.category}</Card.Subtitle>
          <Card.Text>
            <strong>Price:</strong> {formattedPrice}
          </Card.Text>
          <Card.Text>
            <strong>Description:</strong> {product.description}
          </Card.Text>
        </Card.Body>
      </Card>
    </>
  );
}

export default ProductDetailPage;
