import React from 'react';
import { Alert, Spinner } from 'react-bootstrap';
import ProductList from '../components/ProductList';
import { useProducts } from '../context/ProductContext';

function ProductListPage() {
  const { products, loading, error } = useProducts();

  return (
    <>
      <h2 className="mb-4">Product Catalog</h2>

      {loading ? (
        <div className="text-center py-4">
          <Spinner animation="border" role="status" />
        </div>
      ) : null}

      {!loading && error ? <Alert variant="danger">{error}</Alert> : null}

      {!loading && !error ? <ProductList products={products} /> : null}
    </>
  );
}

export default ProductListPage;

