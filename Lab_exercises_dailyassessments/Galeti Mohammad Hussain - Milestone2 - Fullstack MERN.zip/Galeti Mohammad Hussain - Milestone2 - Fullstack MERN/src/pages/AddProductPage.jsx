import React, { useState } from 'react';
import { Card } from 'react-bootstrap';
import { useNavigate } from 'react-router-dom';
import AddProductForm from '../components/AddProductForm';
import { useProducts } from '../context/ProductContext';

function AddProductPage() {
  const navigate = useNavigate();
  const { addProduct } = useProducts();
  const [submitError, setSubmitError] = useState('');

  const handleSubmit = async (values, { resetForm, setSubmitting }) => {
    setSubmitError('');
    try {
      await addProduct({
        ...values,
        price: Number(values.price),
      });
      resetForm();
      navigate('/products');
    } catch (err) {
      setSubmitError(err.message);
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <>
      <h2 className="mb-4">Add Product</h2>
      <Card>
        <Card.Body>
          <AddProductForm onSubmit={handleSubmit} submitError={submitError} />
        </Card.Body>
      </Card>
    </>
  );
}

export default AddProductPage;

