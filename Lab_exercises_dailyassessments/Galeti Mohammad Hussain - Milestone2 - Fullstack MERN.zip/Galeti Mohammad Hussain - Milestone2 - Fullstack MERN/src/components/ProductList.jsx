import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { Col, Row } from 'react-bootstrap';
import ProductCard from './ProductCard';

class ProductList extends Component {
  constructor(props) {
    super(props);
    this.state = {
      favorites: {},
    };
  }

  handleToggleFavorite = (productId) => {
    this.setState((prevState) => ({
      favorites: {
        ...prevState.favorites,
        [productId]: !prevState.favorites[productId],
      },
    }));
  };

  render() {
    const { products } = this.props;
    const { favorites } = this.state;

    if (!products.length) {
      return <p className="text-muted">No products available.</p>;
    }

    return (
      <Row className="g-4">
        {products.map((product) => (
          <Col key={product.id} md={6} lg={4}>
            <ProductCard
              product={product}
              isFavorite={Boolean(favorites[product.id])}
              onToggleFavorite={this.handleToggleFavorite}
            />
          </Col>
        ))}
      </Row>
    );
  }
}

ProductList.propTypes = {
  products: PropTypes.arrayOf(
    PropTypes.shape({
      id: PropTypes.oneOfType([PropTypes.number, PropTypes.string]).isRequired,
      name: PropTypes.string.isRequired,
      price: PropTypes.oneOfType([PropTypes.number, PropTypes.string]).isRequired,
      category: PropTypes.string.isRequired,
    })
  ).isRequired,
};

export default ProductList;

