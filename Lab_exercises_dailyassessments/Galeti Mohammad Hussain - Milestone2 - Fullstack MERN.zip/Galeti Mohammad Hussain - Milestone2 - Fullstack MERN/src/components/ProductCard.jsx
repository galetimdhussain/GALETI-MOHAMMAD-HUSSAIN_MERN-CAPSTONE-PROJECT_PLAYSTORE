import React from 'react';
import PropTypes from 'prop-types';
import { Button, Card } from 'react-bootstrap';
import { Link } from 'react-router-dom';

function ProductCard({ product, isFavorite, onToggleFavorite }) {
  const numericPrice = Number(product.price);
  const formattedPrice = Number.isNaN(numericPrice)
    ? 'N/A'
    : new Intl.NumberFormat('en-IN', {
        style: 'currency',
        currency: 'INR',
      }).format(numericPrice);

  return (
    <Card className="h-100 shadow-sm">
      <Card.Body className="d-flex flex-column">
        <Card.Title>{product.name}</Card.Title>
        <Card.Subtitle className="mb-2 text-muted">{product.category}</Card.Subtitle>
        <Card.Text className="mb-2">Price: {formattedPrice}</Card.Text>
        <div className="mt-auto d-flex gap-2">
          <Button as={Link} to={`/products/${product.id}`} variant="primary">
            View Details
          </Button>
          <Button
            type="button"
            onClick={() => onToggleFavorite(product.id)}
            variant={isFavorite ? 'warning' : 'outline-warning'}
          >
            {isFavorite ? 'Unfavorite' : 'Favorite'}
          </Button>
        </div>
      </Card.Body>
    </Card>
  );
}

ProductCard.propTypes = {
  product: PropTypes.shape({
    id: PropTypes.oneOfType([PropTypes.number, PropTypes.string]).isRequired,
    name: PropTypes.string.isRequired,
    price: PropTypes.oneOfType([PropTypes.number, PropTypes.string]).isRequired,
    category: PropTypes.string.isRequired,
  }).isRequired,
  isFavorite: PropTypes.bool.isRequired,
  onToggleFavorite: PropTypes.func.isRequired,
};

export default ProductCard;
