import React from 'react';
import PropTypes from 'prop-types';
import { ErrorMessage, Field, Form, Formik } from 'formik';
import { Alert, Button } from 'react-bootstrap';
import * as Yup from 'yup';

const productValidationSchema = Yup.object({
  name: Yup.string().trim().min(2, 'Name must be at least 2 characters').required('Name is required'),
  price: Yup.number()
    .typeError('Price must be a number')
    .positive('Price must be greater than 0')
    .required('Price is required'),
  category: Yup.string().trim().required('Category is required'),
  description: Yup.string()
    .trim()
    .min(10, 'Description must be at least 10 characters')
    .required('Description is required'),
});

function AddProductForm({ onSubmit, submitError }) {
  return (
    <Formik
      initialValues={{
        name: '',
        price: '',
        category: '',
        description: '',
      }}
      validationSchema={productValidationSchema}
      onSubmit={onSubmit}
    >
      {({ isSubmitting }) => (
        <Form noValidate>
          {submitError ? <Alert variant="danger">{submitError}</Alert> : null}

          <div className="mb-3">
            <label htmlFor="name" className="form-label">
              Name
            </label>
            <Field id="name" name="name" type="text" className="form-control" />
            <div className="text-danger small">
              <ErrorMessage name="name" />
            </div>
          </div>

          <div className="mb-3">
            <label htmlFor="price" className="form-label">
              Price (INR)
            </label>
            <Field id="price" name="price" type="text" className="form-control" />
            <div className="text-danger small">
              <ErrorMessage name="price" />
            </div>
          </div>

          <div className="mb-3">
            <label htmlFor="category" className="form-label">
              Category
            </label>
            <Field id="category" name="category" type="text" className="form-control" />
            <div className="text-danger small">
              <ErrorMessage name="category" />
            </div>
          </div>

          <div className="mb-3">
            <label htmlFor="description" className="form-label">
              Description
            </label>
            <Field id="description" name="description" as="textarea" rows="4" className="form-control" />
            <div className="text-danger small">
              <ErrorMessage name="description" />
            </div>
          </div>

          <Button type="submit" variant="success" disabled={isSubmitting}>
            {isSubmitting ? 'Saving...' : 'Add Product'}
          </Button>
        </Form>
      )}
    </Formik>
  );
}

AddProductForm.propTypes = {
  onSubmit: PropTypes.func.isRequired,
  submitError: PropTypes.string,
};

AddProductForm.defaultProps = {
  submitError: '',
};

export default AddProductForm;
