                                      React Product Dashboard with Backend Integration

Project Overview:
This project is a React-based product dashboard created for academic coursework assessment. The application allows users to view a catalog of products, navigate to a detailed view of each product, and add new products through a validated form. The backend integration is handled using json-server. The main objective of this project is to demonstrate practical understanding of component-based architecture, routing, API communication, form validation, and state management in a single integrated application.

Technologies and Dependencies Used:
React is the core library used to build the user interface with reusable components and reactive state updates.

react-router-dom is used to manage client-side routing between the product list page, product detail page, and add product page.

axios is used for HTTP communication with the backend API running on localhost port 4000. It handles GET and POST requests for product data.

bootstrap and react-bootstrap are used to provide responsive layout, cards, forms, navigation, and consistent visual styling.

formik is used to create and manage the add product form with controlled form state and submit handling.

yup is used with Formik to define schema-based validation rules for name, price, category, and description.

react-transition-group is used to add route transition effects so page navigation appears smooth and clear.

Context API is used for global state management of products. It fetches products once, stores them globally, and updates the list after a successful POST request.

json-server is used as a mock backend and provides REST endpoints such as GET /products and POST /products.

@reduxjs/toolkit and react-redux are installed in the project dependencies, but they are not used in this implementation because the project requirements are completed using Context API.

Folder Structure Explanation:
The src/components folder contains reusable UI components such as ProductCard, ProductList, AppLayout, and AddProductForm. This folder handles presentation and local interaction logic.

The src/pages folder contains page-level components including ProductListPage, ProductDetailPage, and AddProductPage. These pages connect routing with components and context data.

The src/context folder contains ProductContext, which manages global product state, API fetch status, error state, and add product updates.

The src/services folder contains productService, which centralizes axios API methods and keeps API logic separate from UI components.

App.js is the main integration file that sets up BrowserRouter, route definitions, lazy loading, Suspense fallback, transition wrappers, and context provider usage.

db.json stores backend product data used by json-server. The products array is the data source for list rendering and detail lookup.

User Story 1 Implementation:
The ProductCard component is implemented as a functional component. It receives product data and action handlers through props and displays product name, category, and price in a Bootstrap card layout.

The ProductList component is implemented as a class component as required. It receives the product list through props and renders ProductCard items in a responsive grid.

Props are used to pass product objects, favorite status, and favorite toggle handlers from ProductList to ProductCard. This satisfies the data flow requirement between components.

Local component state is used in ProductList to manage favorite toggle behavior. Favorites are stored as UI-only state and are not persisted in context or backend.

Bootstrap styling is applied using card, grid, spacing, and button classes through react-bootstrap components. This meets the styling requirement for a clean product catalog layout.

All User Story 1 rubric points are satisfied through correct usage of functional and class components, props, state, event handling, and Bootstrap-based UI.

User Story 2 Implementation:
Routing is implemented with paths for product list, product detail, and add product pages. The root path redirects to the product list to ensure a clear entry point.

API integration uses json-server with axios. ProductContext performs GET /products and stores the data globally. Product detail uses route params to identify and display the selected product from context.

Loading and error handling are implemented with try-catch logic in context for API calls. Spinner and alert components are shown in pages based on loading and error state.

The Product Detail page reads the product id from route parameters and finds the matching item from context products. If not found, a clear fallback message is displayed.

Route transitions are implemented using react-transition-group and CSS classes for fade effects when moving between pages.

User Story 2 rubric requirements are satisfied by routing, backend GET integration, loading and error handling, and page transitions.

User Story 3 Implementation:
Formik is configured in AddProductForm with initial values and submit handling. The form includes fields for name, price, category, and description as required.

Yup validation rules enforce required values, price as a positive number, minimum length for name, and minimum length for description. Validation messages are displayed below each field.

On submit, a POST request is sent through context using axios service methods. The submitted price is converted to a number before posting.

Context API updates the global product list immediately after successful POST by appending the newly created product response.

After successful submission, the form is reset and the user is redirected to the product list page to verify that the new product is added.

User Story 3 rubric requirements are satisfied through Formik form control, Yup validation, POST integration, context update flow, and Bootstrap-based form styling.

Bonus Implementation:
The ProductDetailPage is loaded using React.lazy, and Suspense is used to show a loading spinner fallback while the component is being loaded. This satisfies the lazy loading bonus requirement.

Approach and Design Decisions:
Context API was selected for global product state because the application needs shared product data across multiple pages with lightweight state management. This approach keeps the data flow simple and avoids unnecessary complexity.

The folder structure follows separation of concerns. Components focus on UI rendering, pages handle route-level composition, context manages shared state, and services isolate API logic. This improves readability and maintainability.

Integration across user stories is achieved by using one shared product state source. The product list displays fetched data, the detail page reads the selected product from the same data source, and the add product form updates the same state after POST. This creates one consistent application flow.

Conclusion:
This project successfully completes the React Product Dashboard assessment by integrating component-based design, routing, backend communication, validated form handling, and global state management in one application. The final implementation follows the required rubric and demonstrates practical full flow integration from product listing to product creation.
