const EventEmitter = require("events");

const eventEmitter = new EventEmitter();

eventEmitter.on("userLoggedIn", (name) => {
    console.log(`User ${name} logged in.`);
});

eventEmitter.on("userLoggedOut", (name) => {
    console.log(`User ${name} logged out.`);
});

eventEmitter.on("sessionExpired", (name) => {
    console.log(`Session expired for ${name}.`);
});

eventEmitter.emit("userLoggedIn", "John");

setTimeout(() => {
    eventEmitter.emit("sessionExpired", "John");
}, 5000);

setTimeout(() => {
    eventEmitter.emit("userLoggedOut", "John");
}, 6000);