const fs = require("fs").promises;

async function run() {
    try {
        const userInput = "Node.js is awesome!";

        await fs.writeFile("feedback.txt", userInput);
        console.log("Data written successfully.");

        console.log("Reading file...");
        const data = await fs.readFile("feedback.txt", "utf8");
        console.log(data);

    } catch (error) {
        console.error(error);
    }
}

run();