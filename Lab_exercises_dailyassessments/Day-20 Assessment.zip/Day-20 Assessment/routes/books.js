const express = require("express");
const router = express.Router();

let books = [
    { id: 1, title: "1984", author: "Orwell" },
    { id: 2, title: "The Alchemist", author: "Coelho" }
];

router.get("/", (req, res) => {
    res.json(books);
});

router.post("/", (req, res) => {

    const { title, author } = req.body;

    if (!title || !author) {
        return res.status(400).json({ error: "Title and Author required" });
    }

    const newBook = {
        id: books.length + 1,
        title,
        author
    };

    books.push(newBook);
    res.status(201).json(newBook);
});

router.put("/:id", (req, res) => {

    const id = parseInt(req.params.id);
    const book = books.find(b => b.id === id);

    if (!book) {
        return res.status(404).json({ error: "Book not found" });
    }

    book.title = req.body.title || book.title;
    book.author = req.body.author || book.author;

    res.json(book);
});

router.delete("/:id", (req, res) => {

    const id = parseInt(req.params.id);
    books = books.filter(b => b.id !== id);

    res.json({ message: "Book deleted" });
});

module.exports = router;