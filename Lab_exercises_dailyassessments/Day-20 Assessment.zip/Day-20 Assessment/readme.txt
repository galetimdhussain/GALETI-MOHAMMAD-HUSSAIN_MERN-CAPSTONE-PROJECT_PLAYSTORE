Project Explanation – BookStore Mini REST API using Express.js


This project is a simple backend application built using Node.js and Express. The main goal of this project is to understand how Express helps in building REST APIs in a structured and modular way. It demonstrates routing, middleware, query parameters, CRUD operations, modular routing, and proper error handling.

The project starts by setting up an Express server that runs on port 4000. Once the server is running, it listens for incoming HTTP requests and responds based on the defined routes. The root route returns a simple welcome message to confirm that the server is working properly. A status route is also added to return a JSON response showing that the server is running.

A custom middleware is implemented to log every incoming request. This middleware captures the HTTP method, the requested URL, and the current timestamp. This helps in monitoring API usage and debugging issues. The middleware is added globally so that it runs for every request before reaching any route.

The project also includes a route that demonstrates the use of query parameters. The products route checks whether a name query parameter is provided. If it is provided, it returns the value in JSON format. If not, it responds with a message asking the user to provide a product name. This shows how dynamic filtering can be implemented using req.query.

The main part of the project is the Books REST API. It uses an in memory array to store book objects. Each book contains an id, title, and author. The following operations are implemented:

GET /books returns all books.
POST /books adds a new book after validating that both title and author are provided.
PUT /books/:id updates an existing book using route parameters.
DELETE /books/:id removes a book from the list.

Route parameters are handled using req.params. Input validation ensures that incomplete data is not accepted. If required fields are missing, the server responds with a 400 status and an appropriate error message.

To keep the project organized, all book related routes are moved into a separate file inside a routes folder. This modular routing approach improves maintainability and keeps the main server file clean. The routes are then imported into server.js using app.use.

A global error handling middleware is added to catch unexpected server errors and return a structured JSON response. A 404 handler is also implemented to return a custom message when a user accesses an undefined route. This ensures graceful error handling and improves the reliability of the API.

The project can be tested using a browser for GET requests and tools like Postman for POST, PUT, and DELETE requests. The server logs each request in the console, making it easy to verify middleware functionality.

Overall, this project demonstrates core Express fundamentals including server setup, routing, middleware usage, handling query parameters, building RESTful APIs, modular structure, validation, and error handling. It serves as a complete introduction to building backend services using Express in a clean and structured manner.