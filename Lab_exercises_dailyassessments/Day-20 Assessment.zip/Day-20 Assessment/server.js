const express = require("express");
const bookRouter = require("./routes/books");

const app = express();
const PORT = 4000;

app.use((req, res, next) => {
    const timestamp = new Date().toISOString();
    console.log(`[${req.method}] ${req.url} - ${timestamp}`);
    next();
});

app.use(express.json());

app.use("/books", bookRouter);

app.get("/", (req, res) => {
    res.send("Welcome to Express Server");
});

// Bonus route
app.get("/status", (req, res) => {
    res.json({ server: "running", uptime: "OK" });
});

app.get("/products", (req, res) => {

    const name = req.query.name;

    if (name) {
        // Bonus: JSON response
        res.json({ query: name });
    } else {
        res.send("Please provide a product name");
    }

});

app.use((err, req, res, next) => {
    console.error(err.stack);
    res.status(500).json({ error: "Internal Server Error" });
});

app.use((req, res) => {
    res.status(404).send("Route not found");
});

app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
});