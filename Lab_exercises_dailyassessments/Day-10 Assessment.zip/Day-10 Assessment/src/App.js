import React from "react";
import { Routes, Route, Navigate, Link } from "react-router-dom";
import Home from "./pages/Home";
import BookDetails from "./pages/BookDetails";
import "./App.css";

function App() {
  return (
    <div className="background">
      <nav className="navbar navbar-dark bg-dark px-3">
        <Link className="navbar-brand" to="/home">BookVerse</Link>
      </nav>

      <div className="fade-page">
        <Routes>
          <Route path="/" element={<Navigate to="/home" />} />
          <Route path="/home" element={<Home />} />
          <Route path="/book/:id" element={<BookDetails />} />
        </Routes>
      </div>
    </div>
  );
}

export default App;
