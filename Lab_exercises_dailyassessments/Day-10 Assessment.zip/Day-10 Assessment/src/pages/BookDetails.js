import React, { useEffect, useState } from "react";
import { useParams, Link } from "react-router-dom";
import axios from "axios";

function BookDetails() {
  const { id } = useParams();
  const [book, setBook] = useState(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    setIsLoading(true);
    axios.get(`http://localhost:3003/books/${id}`)
      .then(res => {
        setBook(res.data);
        setIsLoading(false);
      })
      .catch(err => {
        console.error("Error fetching book:", err);
        setIsLoading(false);
      });
  }, [id]);

  if (isLoading) {
    return (
      <div className="text-center mt-5">
        <div className="spinner-border text-primary"></div>
        <p>Loading...</p>
      </div>
    );
  }

  if (!book) {
    return (
      <div className="container mt-4">
        <p>Book not found.</p>
        <Link className="btn btn-secondary" to="/home">Back</Link>
      </div>
    );
  }

  return (
    <div className="container mt-4">
      <Link className="btn btn-secondary mb-3" to="/home">Back</Link>

      <div className="card p-4">
        <h2>{book.title}</h2>
        <h5>{book.author}</h5>
        <p className="text-success">₹{book.price}</p>
        <p>{book.description}</p>
      </div>
    </div>
  );
}

export default BookDetails;
