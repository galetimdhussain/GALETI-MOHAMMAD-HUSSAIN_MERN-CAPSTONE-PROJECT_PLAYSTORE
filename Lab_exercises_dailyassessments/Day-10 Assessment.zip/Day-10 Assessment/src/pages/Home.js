import React, { useEffect, useState } from "react";
import axios from "axios";
import { Link } from "react-router-dom";
import UserGreeting from "../components/UserGreeting";

function Home() {
  const [books, setBooks] = useState([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    setIsLoading(true);
    axios.get("http://localhost:3003/books")
      .then(res => {
        setBooks(res.data);
        setIsLoading(false);
      })
      .catch(err => {
        console.error("Error fetching books:", err);
        setIsLoading(false);
      });
  }, []);

  if (isLoading) {
    return (
      <div className="text-center mt-5">
        <div className="spinner-border text-primary"></div>
        <p>Loading...</p>
      </div>
    );
  }

  return (
    <div className="container mt-4">
      <UserGreeting render={(name) => (
        <h3>Welcome, {name}</h3>
      )} />

      <h2 className="mt-3">Home - Find the Books You Love</h2>

      <div className="row mt-4">
        {books.map(book => (
          <div key={book.id} className="col-md-4 mb-3">
            <div className="card p-3">
              <h5>{book.title}</h5>
              <p>{book.author}</p>
              <p>₹{book.price}</p>
              <Link className="btn btn-primary" to={`/book/${book.id}`}>
                View Details
              </Link>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

export default Home;
