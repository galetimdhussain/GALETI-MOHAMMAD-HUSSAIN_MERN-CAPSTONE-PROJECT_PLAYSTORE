# BookVerse: Explore & Navigate Between Pages

## Project Overview

BookVerse is a React-based web application developed as part of Day 12 Assessment on Routing and Backend Integration. The application allows readers to navigate between the Home page and Book Details page, explore book information, and view real-time book data fetched from a local backend.

## User Story

As a reader,
I want to navigate between the Home page and Book Details page,
So that I can explore more about a book and see real-time book data.

## Acceptance Criteria

The following requirements have been implemented and verified:

1. **JSON Server Integration**: Uses json-server to serve a local backend with books.json
2. **Data Fetching**: Fetches book data using axios
3. **React Router Configuration**: Configured React Router for navigation between /home and /book/:id
4. **Routing Transitions**: Implemented simple fade in/out transitions using CSS
5. **Higher Order Component (HOC)**: Created withLoader HOC for loading spinner functionality
6. **Render Props Component**: Implemented UserGreeting as a Render Props component for reusable UI elements

## Technical Focus

The following React concepts were used in this project:

- **React Router**: BrowserRouter, Routes, Route, Link, useParams
- **Routing Transitions**: CSS-based fade in/out animations
- **JSON Server Integration**: Local backend API for book data
- **Higher Order Components**: withLoader HOC for wrapping components with loading state
- **Render Props**: UserGreeting component using render props pattern

## Technology Stack

### Core Dependencies

| Package | Version | Purpose |
|---------|---------|---------|
| react | 19.2.4 | Frontend framework |
| react-dom | 19.2.4 | React DOM rendering |
| react-router-dom | 7.13.0 | Client-side routing |
| axios | 1.13.5 | HTTP client for API requests |
| bootstrap | 5.3.8 | CSS framework for styling |
| react-scripts | 5.0.1 | Create React App scripts |

### Development Dependencies

| Package | Version | Purpose |
|---------|---------|---------|
| json-server | (via npm) | Mock REST API server |
| @testing-library/react | 16.3.2 | React testing utilities |
| @testing-library/jest-dom | 6.9.1 | Jest DOM matchers |

## Project Structure

```
bookverse/
├── public/
│   └── index.html           # Main HTML template
├── src/
│   ├── components/
│   │   ├── UserGreeting.js  # Render Props component for user greeting
│   │   └── withLoader.js    # Higher Order Component for loading spinner
│   ├── pages/
│   │   ├── Home.js          # Home page with book list
│   │   └── BookDetails.js   # Book details page with route parameter
│   ├── App.js               # Main app with Router configuration
│   ├── App.css              # App styles including fade transitions
│   ├── index.js             # Application entry point
│   └── index.css            # Global styles with background color
├── books.json               # JSON Server database file
└── package.json             # Project configuration
```

## Getting Started

### Prerequisites

Ensure you have the following installed:

- Node.js (version 14 or higher)
- npm (comes with Node.js)

### Installation

1. Navigate to the project directory:

```
cd bookverse
```

2. Install all dependencies:

```
npm install
```

This will install all packages defined in package.json.

### Running the Application

You need to run two services simultaneously:

**Step 1: Start the JSON Server (Backend)**

Open a terminal and run:

```
npm run json-server
```

This starts the JSON Server on port 3003 and watches the books.json file to serve as a REST API.

**Step 2: Start the React Development Server**

Open a new terminal and run:

```
npm start
```

This starts the React application on http://localhost:3000.

## Application Features

### Home Page (/home)

The home page displays a list of all books from the JSON Server database. Features include:

- Navigation bar with BookVerse branding
- UserGreeting component displaying welcome message
- Book cards showing title, author, and cover image
- Loading spinner while fetching data
- Error handling for failed requests
- Links to individual book details pages

### Book Details Page (/book/:id)

When clicking on a book, users are navigated to the details page showing:

- Full book information (title, author, description, cover)
- Price and rating display
- Loading state while fetching book data
- Back navigation to home page
- Route parameter (id) handling via useParams hook

### Higher Order Component: withLoader

The withLoader HOC wraps components with loading spinner functionality. It:

- Shows a loading spinner while data is being fetched
- Displays the actual content once data is loaded
- Provides consistent loading UX across the application

### Render Props Component: UserGreeting

The UserGreeting component uses the render props pattern to:

- Display personalized welcome messages
- Reusable UI for greeting elements
- Flexible rendering through props

### Routing and Transitions

The application implements:

- BrowserRouter for HTML5 history API
- Routes and Route components for path matching
- Link component for navigation without page reload
- useParams hook for accessing dynamic route parameters
- CSS fade transitions between pages

## API Endpoints

The JSON Server provides the following REST endpoints:

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | http://localhost:3003/books | Retrieve all books |
| GET | http://localhost:3003/books/:id | Retrieve specific book by ID |

## Styling and Design

### Background Theme

The application uses a blue background color (#529be4) applied to the entire viewport:

```
background-color: #529be4 !important;
min-height: 100vh;
```

### Routing Transitions

Fade in/out animations are implemented in App.css using CSS transitions for smooth page navigation.

## Available npm Scripts

| Script | Command | Description |
|--------|---------|-------------|
| Start | `npm start` | Runs the React development server |
| JSON Server | `npm run json-server` | Runs the mock REST API server |
| Build | `npm run build` | Creates production build |
| Test | `npm test` | Runs test suite |
| Eject | `npm run eject` | Ejects from Create React App |

## Time Estimate

This project was completed within the estimated time of 60 minutes as specified in the assessment requirements.

## Verification Checklist

All acceptance criteria have been met:

- JSON Server is running and serving books.json data
- Book data is fetched using axios library
- React Router is configured with routes for /home and /book/:id
- Fade in/out transitions are implemented using CSS
- withLoader HOC provides loading spinner functionality
- UserGreeting component implements render props pattern

## Troubleshooting

### Port Already in Use

If port 3000 or 3003 is already in use, you can specify alternative ports:

```
PORT=3001 npm start
npm run json-server -- --port 3004
```

### JSON Server Not Working

Ensure the books.json file exists in the project root and the JSON Server is running before accessing the application.

### Build Errors

If you encounter build errors, try reinstalling dependencies:

```
rm -rf node_modules
npm install
```

## Learning Resources

To learn more about the technologies used:

- React Router: https://reactrouter.com/web/guides/quick-start
- JSON Server: https://github.com/typicode/json-server
- React HOCs: https://reactjs.org/docs/higher-order-components.html
- Render Props: https://reactjs.org/docs/render-props.html
- Axios: https://axios-http.com/docs/intro
- Bootstrap: https://getbootstrap.com/docs/5.3/getting-started/introduction/

---

This project was created as part of the Day 12 Assessment to demonstrate routing and backend integration in React applications.
