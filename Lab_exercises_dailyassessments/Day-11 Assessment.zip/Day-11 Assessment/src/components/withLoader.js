import React from "react";

function withLoader(WrappedComponent) {
  return function LoaderComponent({ isLoading, ...props }) {
    if (isLoading) {
      return (
        <div className="text-center mt-5">
          <div className="spinner-border text-primary"></div>
          <p>Loading...</p>
        </div>
      );
    }
    return <WrappedComponent {...props} />;
  };
}

export default withLoader;