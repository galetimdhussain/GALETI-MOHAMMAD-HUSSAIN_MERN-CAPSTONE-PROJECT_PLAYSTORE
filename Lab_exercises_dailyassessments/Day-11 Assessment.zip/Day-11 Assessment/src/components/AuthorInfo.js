import React, { Component } from "react";

class AuthorInfo extends Component {

  componentDidMount() {
    console.log("Author component mounted");
  }

  render() {
    const { author } = this.props;

    if (!author) {
      return <div className="mt-4">Click a book to view author details</div>;
    }

    const authors = {
      "Paulo Coelho": {
        bio: "Brazilian novelist known for inspirational fiction.",
        books: ["The Alchemist", "Brida", "Eleven Minutes"]
      },
      "James Clear": {
        bio: "Writer and speaker focused on habits and productivity.",
        books: ["Atomic Habits", "Better Habits", "Habit Journal"]
      },
      "Hector Garcia": {
        bio: "Author exploring Japanese culture and lifestyle.",
        books: ["Ikigai", "A Geek in Japan", "The Ikigai Journey"]
      },
      "Robert Kiyosaki": {
        bio: "Entrepreneur and financial educator.",
        books: ["Rich Dad Poor Dad", "Cashflow Quadrant", "Retire Young"]
      },
      "A.P.J Abdul Kalam": {
        bio: "Indian aerospace scientist and former President of India.",
        books: ["Wings of Fire", "Ignited Minds", "India 2020"]
      }
    };

    const data = authors[author];

    return (
      <div className="card mt-4 p-3">
        <h4>{author}</h4>
        <p>{data.bio}</p>
        <h6>Top 3 Books</h6>
        <ul>
          {data.books.map((book, index) => (
            <li key={index}>{book}</li>
          ))}
        </ul>
      </div>
    );
  }
}

export default AuthorInfo;