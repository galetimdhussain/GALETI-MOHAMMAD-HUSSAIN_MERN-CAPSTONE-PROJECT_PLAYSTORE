import React from "react";
import PropTypes from "prop-types";

function BookCard({ title, author, price, onSelect }) {
  return (
    <div
      className="card h-100 p-3"
      onClick={() => onSelect(author)}
      style={{ cursor: "pointer" }}
    >
      <h5 className="card-title">{title}</h5>
      <p className="card-text">Author: {author}</p>
      <p className="card-text text-success">₹{price}</p>
    </div>
  );
}

BookCard.propTypes = {
  title: PropTypes.string.isRequired,
  author: PropTypes.string.isRequired,
  price: PropTypes.number.isRequired,
  onSelect: PropTypes.func.isRequired
};

export default BookCard;