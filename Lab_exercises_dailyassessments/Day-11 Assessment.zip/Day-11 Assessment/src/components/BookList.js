import React, { useState, useRef } from "react";
import BookCard from "./BookCard";
import AuthorInfo from "./AuthorInfo";

function BookList() {

  const books = [
    { id: 1, title: "The Alchemist", author: "Paulo Coelho", price: 399 },
    { id: 2, title: "Atomic Habits", author: "James Clear", price: 499 },
    { id: 3, title: "Ikigai", author: "Hector Garcia", price: 299 },
    { id: 4, title: "Rich Dad Poor Dad", author: "Robert Kiyosaki", price: 450 },
    { id: 5, title: "Wings of Fire", author: "A.P.J Abdul Kalam", price: 350 }
  ];

  const [search, setSearch] = useState("");
  const [viewMode, setViewMode] = useState("grid");
  const [selectedAuthor, setSelectedAuthor] = useState(null);

  const searchRef = useRef(null);

  const focusInput = () => {
    searchRef.current.focus();
  };

  const filteredBooks = books.filter(book =>
    book.title.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="container mt-4">

      <div className="d-flex justify-content-between align-items-center">
        <h2>Featured Books</h2>
        <button className="btn btn-primary" onClick={focusInput}>
          Focus Search
        </button>
      </div>

      <input
        ref={searchRef}
        type="text"
        className="form-control mt-3"
        placeholder="Search book..."
        value={search}
        onChange={(e) => setSearch(e.target.value)}
      />

      <div className="mt-3">
        <button
          className="btn btn-outline-secondary me-2"
          onClick={() => setViewMode("grid")}
        >
          Grid
        </button>
        <button
          className="btn btn-outline-secondary"
          onClick={() => setViewMode("list")}
        >
          List
        </button>
      </div>

      <div className={`row mt-4 ${viewMode === "list" ? "flex-column" : ""}`}>
        {filteredBooks.map(book => (
          <div
            key={book.id}
            className={viewMode === "grid" ? "col-md-4 mb-3" : "col-12 mb-2"}
          >
            <BookCard
              title={book.title}
              author={book.author}
              price={book.price}
              onSelect={setSelectedAuthor}
            />
          </div>
        ))}
      </div>

      <AuthorInfo author={selectedAuthor} />
    </div>
  );
}

export default BookList;