import React from "react";

function UserGreeting({ render }) {
  const user = "Reader";
  return render(user);
}

export default UserGreeting;