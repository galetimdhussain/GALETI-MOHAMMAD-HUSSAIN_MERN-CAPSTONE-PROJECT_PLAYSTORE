import BookStore from "./BookStore";
import ApiService from "./ApiService";

export const createBookStore = (apiService = new ApiService()) => {
  return new BookStore(apiService);
};

const bookStore = createBookStore();

export default bookStore;
