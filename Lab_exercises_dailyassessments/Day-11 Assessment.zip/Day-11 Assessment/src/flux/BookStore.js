import dispatcher from "./Dispatcher";
import { BOOK_ACTION_TYPES } from "./BookActions";

class BookStore {
  constructor(apiService) {
    this.serverBooks = [];
    this.listeners = [];
    this.apiService = apiService;
    this.isLoading = false;
    this.error = null;
    this.requestId = 0;

    dispatcher.register(this.handleActions.bind(this));
  }

  handleActions(action) {
    if (action.type === BOOK_ACTION_TYPES.ADD_BOOK) {
      this.createBook(action.payload);
    }
  }

  async createBook(book) {
    const currentRequestId = ++this.requestId;
    this.isLoading = true;
    this.error = null;
    this.emitChange();

    try {
      const createdBook = await this.apiService.createBook(book);
      if (currentRequestId === this.requestId) {
        this.serverBooks.push(createdBook);
      }
    } catch (error) {
      if (currentRequestId === this.requestId) {
        this.error = error instanceof Error ? error.message : "Failed to add book";
      }
    } finally {
      if (currentRequestId === this.requestId) {
        this.isLoading = false;
        this.emitChange();
      }
    }
  }

  async loadBooks() {
    const currentRequestId = ++this.requestId;
    this.isLoading = true;
    this.error = null;
    this.emitChange();

    try {
      const books = await this.apiService.fetchBooks();
      if (currentRequestId === this.requestId) {
        this.serverBooks = Array.isArray(books) ? books : [];
      }
    } catch (error) {
      if (currentRequestId === this.requestId) {
        this.error = error instanceof Error ? error.message : "Failed to load books";
      }
    } finally {
      if (currentRequestId === this.requestId) {
        this.isLoading = false;
        this.emitChange();
      }
    }
  }

  getBooks() {
    return this.serverBooks;
  }

  getBookById(id) {
    return this.getBooks().find((book) => String(book.id) === String(id)) || null;
  }

  getIsLoading() {
    return this.isLoading;
  }

  getError() {
    return this.error;
  }

  addListener(listener) {
    this.listeners.push(listener);
  }

  removeListener(listener) {
    this.listeners = this.listeners.filter(l => l !== listener);
  }

  emitChange() {
    this.listeners.forEach(listener => listener());
  }
}

export default BookStore;
