class ApiService {
  constructor(baseUrl = "http://localhost:3003") {
    this.baseUrl = baseUrl;
  }

  async fetchBooks() {
    const response = await fetch(`${this.baseUrl}/books`);
    if (!response.ok) {
      throw new Error("Failed to fetch books");
    }
    return response.json();
  }

  async fetchBookById(id) {
    const response = await fetch(`${this.baseUrl}/books/${id}`);
    if (!response.ok) {
      throw new Error("Failed to fetch book");
    }
    return response.json();
  }

  async createBook(book) {
    const response = await fetch(`${this.baseUrl}/books`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify(book)
    });

    if (!response.ok) {
      throw new Error("Failed to add book");
    }

    return response.json();
  }
}

export default ApiService;

