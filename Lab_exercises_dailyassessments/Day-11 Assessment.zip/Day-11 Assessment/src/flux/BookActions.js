import dispatcher from "./Dispatcher";

export const BOOK_ACTION_TYPES = {
  ADD_BOOK: "ADD_BOOK"
};

export const addBook = (book) => {
  dispatcher.dispatch({
    type: BOOK_ACTION_TYPES.ADD_BOOK,
    payload: book
  });
};
