class Dispatcher {
  constructor() {
    this.callbacks = [];
  }

  register(callback) {
    this.callbacks.push(callback);
  }

  dispatch(action) {
    return Promise.all(this.callbacks.map((cb) => cb(action)));
  }
}

const dispatcher = new Dispatcher();
export default dispatcher;
