import React from "react";
import { Formik, Form, Field, ErrorMessage } from "formik";
import * as Yup from "yup";
import { addBook } from "../flux/BookActions";
import { useNavigate } from "react-router-dom";

const BookSchema = Yup.object().shape({
  title: Yup.string().required("Title required"),
  author: Yup.string().required("Author required"),
  price: Yup.number()
    .typeError("Price must be a number")
    .positive("Price must be greater than 0")
    .required("Price required")
});

function AddBook() {

  const navigate = useNavigate();

  return (
    <div className="container mt-4">
      <h2>Add New Book</h2>

      <Formik
        initialValues={{ title: "", author: "", price: "" }}
        validationSchema={BookSchema}
        onSubmit={(values, { setSubmitting, resetForm }) => {
          addBook({
            title: values.title.trim(),
            author: values.author.trim(),
            price: Number(values.price)
          });
          resetForm();
          setSubmitting(false);
          navigate("/home");
        }}
      >
        {({ isSubmitting }) => (
          <Form className="mt-3">

            <div className="mb-3">
              <label>Title</label>
              <Field name="title" className="form-control" />
              <ErrorMessage name="title" component="div" className="text-danger" />
            </div>

            <div className="mb-3">
              <label>Author</label>
              <Field name="author" className="form-control" />
              <ErrorMessage name="author" component="div" className="text-danger" />
            </div>

            <div className="mb-3">
              <label>Price</label>
              <Field name="price" type="number" className="form-control" />
              <ErrorMessage name="price" component="div" className="text-danger" />
            </div>

            <button type="submit" className="btn btn-success" disabled={isSubmitting}>
              Add Book
            </button>

          </Form>
        )}
      </Formik>
    </div>
  );
}

export default AddBook;
