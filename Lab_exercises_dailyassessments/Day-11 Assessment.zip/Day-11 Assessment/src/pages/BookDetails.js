import React, { useEffect, useState } from "react";
import { useParams, Link } from "react-router-dom";
import bookStore from "../flux/storeInstance";

function BookDetails() {
  const { id } = useParams();
  const [book, setBook] = useState(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const syncFromStore = () => {
      const foundBook = bookStore.getBookById(id);
      setBook(foundBook);
      setIsLoading(bookStore.getIsLoading());
    };

    bookStore.addListener(syncFromStore);
    syncFromStore();

    if (!bookStore.getBookById(id)) {
      bookStore.loadBooks();
    }

    return () => {
      bookStore.removeListener(syncFromStore);
    };
  }, [id]);

  if (isLoading) {
    return (
      <div className="text-center mt-5">
        <div className="spinner-border text-primary"></div>
        <p>Loading...</p>
      </div>
    );
  }

  if (!book) {
    return (
      <div className="container mt-4">
        <p>Book not found.</p>
        <Link className="btn btn-secondary" to="/home">Back</Link>
      </div>
    );
  }

  return (
    <div className="container mt-4">
      <Link className="btn btn-secondary mb-3" to="/home">Back</Link>

      <div className="card p-4">
        <h2>{book.title}</h2>
        <h5>{book.author}</h5>
        <p className="text-success">Rs. {book.price}</p>
        <p>{book.description || "No description available."}</p>
      </div>
    </div>
  );
}

export default BookDetails;
