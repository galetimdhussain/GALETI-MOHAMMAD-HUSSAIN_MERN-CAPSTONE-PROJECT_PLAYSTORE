import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import UserGreeting from "../components/UserGreeting";
import withLoader from "../components/withLoader";
import bookStore from "../flux/storeInstance";

function HomeContent({ books, error }) {
  if (error) {
    return (
      <div className="container mt-4">
        <div className="alert alert-danger">{error}</div>
      </div>
    );
  }

  return (
    <div className="container mt-4">
      {UserGreeting && typeof UserGreeting === "function" ? (
        <UserGreeting render={(name) => <h3>Welcome, {name}</h3>} />
      ) : null}

      <Link to="/add" className="btn btn-success mb-3">Add Book</Link>

      <div className="row">
        {books.length === 0 ? <p>No books available.</p> : null}
        {books.map((book) => (
          <div key={book.id} className="col-md-4 mb-3">
            <div className="card p-3 h-100">
              <h5>{book.title}</h5>
              <p>{book.author}</p>
              <p>Rs. {book.price}</p>
              <Link to={`/book/${book.id}`} className="btn btn-primary mt-auto">View</Link>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

const HomeContentWithLoader = withLoader(HomeContent);

function Home() {
  const [books, setBooks] = useState(() => bookStore.getBooks());
  const [loading, setLoading] = useState(() => bookStore.getIsLoading());
  const [error, setError] = useState(() => bookStore.getError());

  useEffect(() => {
    // Flux lifecycle in React: subscribe on mount -> store emits on action/data change -> cleanup on unmount.
    const syncFromStore = () => {
      setBooks(bookStore.getBooks());
      setLoading(bookStore.getIsLoading());
      setError(bookStore.getError());
    };

    bookStore.addListener(syncFromStore);
    syncFromStore();
    bookStore.loadBooks();

    return () => {
      bookStore.removeListener(syncFromStore);
    };
  }, []);

  return <HomeContentWithLoader isLoading={loading} books={books} error={error} />;
}

export default Home;
