# BookVerse - Day 13 Assessment

## Title
BookVerse: Add New Book and Manage Data Flow

## User Story
As an admin, I want to add new books through a validated form so that I can expand the book collection easily.

## Objective
This project implements:
- Form handling with Formik
- Validation with Yup
- Flux architecture using Action, Dispatcher, and Store
- Dependency Injection for store setup
- SPA navigation with React Router
- Data persistence with JSON Server

## Acceptance Criteria Mapping
1. Formik and Yup are used for form handling and validation.
2. `title`, `author`, and `price` are required.
3. Flux pattern is implemented using:
   - Action: `src/flux/BookActions.js`
   - Dispatcher: `src/flux/Dispatcher.js`
   - Store: `src/flux/BookStore.js`
4. Newly added books are shown on the Home page.
5. Store setup supports Dependency Injection through a factory function.
6. Component lifecycle and Flux data flow are implemented through subscribe, emit, and cleanup.
7. Navigation works as SPA routes without full page reloads.

## Tech Stack
- React 19
- React Router DOM 7
- Formik
- Yup
- Bootstrap 5
- JSON Server

## Dependencies
From `package.json`:

| Package | Version |
|---|---|
| react | ^19.2.4 |
| react-dom | ^19.2.4 |
| react-router-dom | ^7.13.0 |
| formik | ^2.4.9 |
| yup | ^1.7.1 |
| bootstrap | ^5.3.8 |
| axios | ^1.13.5 |
| json-server | ^1.0.0-beta.9 |
| react-scripts | 5.0.1 |

## Project Structure
```text
bookverse/
  books.json
  package.json
  src/
    App.js
    pages/
      Home.js
      AddBook.js
      BookDetails.js
    flux/
      BookActions.js
      Dispatcher.js
      BookStore.js
      ApiService.js
      storeInstance.js
    components/
      withLoader.js
      UserGreeting.js
```

## Flux Implementation
### Action
`addBook(book)` dispatches an `ADD_BOOK` action.

### Dispatcher
A central dispatcher registers callbacks and broadcasts actions to the Store.

### Store
`BookStore`:
- keeps source of truth for books in memory
- loads books from JSON Server via `ApiService.fetchBooks()`
- handles add book flow via `ApiService.createBook()`
- emits change events to subscribed components

### Dependency Injection
`src/flux/storeInstance.js` exposes `createBookStore(apiService)` so the store can be created with a supplied service instance.

## Form Handling and Validation
`src/pages/AddBook.js` uses:
- Formik form state
- Yup schema validation
- Required fields: title, author, price
- Positive numeric check for price

On submit:
1. Form data is validated.
2. Add action is dispatched.
3. Store persists the book through JSON Server.
4. App navigates back to Home route.

## SPA Navigation and Lifecycle
Routes in `src/App.js`:
- `/home`
- `/add`
- `/book/:id`

Lifecycle in Flux context:
1. `Home` subscribes to Store inside `useEffect`.
2. Store emits updates after load and add operations.
3. `Home` updates UI state from Store snapshot.
4. On unmount, listener is removed to avoid leaks.

This keeps data flow one-directional and navigation stays in-app without full page reload.

## API Endpoints (JSON Server)
- `GET http://localhost:3003/books`
- `GET http://localhost:3003/books/:id`
- `POST http://localhost:3003/books`

## Setup Instructions
1. Open terminal in project root:
```bash
cd bookverse
```

2. Install dependencies:
```bash
npm install
```

3. Start JSON Server:
```bash
npm run json-server
```

4. In a second terminal, start React app:
```bash
npm start
```

5. Open:
`http://localhost:3000`

## Verification Steps
1. Go to `/home` and confirm initial books are visible.
2. Go to `/add`.
3. Submit a valid book with title, author, and price.
4. Confirm the new book appears on Home page.
5. Check `books.json` or `GET /books` to confirm backend persistence.
6. Open book details route and verify data is shown.

## Rules Followed in This Implementation
- Required form fields are validated before submit.
- Flux one-way data flow is used for add and read flows.
- Store acts as central state manager for book list.
- API interaction is isolated in service layer.
- Dependency Injection is applied for store creation.
- Navigation uses Router links and route transitions without page refresh.

## Available Scripts
- `npm start` - run React development server
- `npm run json-server` - run JSON Server on port 3003
- `npm run build` - create production build
- `npm test` - run tests

## Troubleshooting
### New books not saved
- Confirm JSON Server is running on `http://localhost:3003`.
- Confirm browser console has no CORS or network errors.
- Confirm POST endpoint works: `POST /books`.

### Empty home page
- Confirm `books.json` exists and has a `books` array.
- Confirm Store load runs without network error.

### Port conflict
- If 3003 is busy, run:
```bash
npm run json-server -- --port 3004
```
Then update `baseUrl` in `src/flux/ApiService.js`.
