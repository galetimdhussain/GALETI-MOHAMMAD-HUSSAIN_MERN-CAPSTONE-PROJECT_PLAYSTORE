import "./App.css";
import React from "react";
import BookList from "./components/BookList";


function App() {
  return (
    <div>
      <h1 className="text-center mt-3">BookVerse</h1>
      <BookList />
    </div>
  );
}

export default App;