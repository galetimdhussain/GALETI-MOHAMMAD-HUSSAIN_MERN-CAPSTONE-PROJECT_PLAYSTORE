import React, { Component } from "react";

class AuthorInfo extends Component {

  componentDidMount() {
    console.log("Author data loaded");
  }

  render() {
    const { author } = this.props;

    if (!author) {
      return <h4 className="mt-4">Select a book to view author details</h4>;
    }

    const authorData = {
      "Paulo Coelho": {
        bio: "Brazilian lyricist and novelist, best known for The Alchemist.",
        books: ["The Alchemist", "Brida", "Eleven Minutes"]
      },
      "James Clear": {
        bio: "Self-improvement author and speaker focused on habits and decision making.",
        books: ["Atomic Habits", "Better Decisions", "Habit Journal"]
      },
      "Hector Garcia": {
        bio: "Author known for books about Japanese philosophy and lifestyle.",
        books: ["Ikigai", "A Geek in Japan", "The Ikigai Journey"]
      },
      "Robert Kiyosaki": {
        bio: "Entrepreneur and financial educator.",
        books: ["Rich Dad Poor Dad", "Cashflow Quadrant", "Retire Young Retire Rich"]
      },
      "A.P.J Abdul Kalam": {
        bio: "Indian aerospace scientist and former President of India.",
        books: ["Wings of Fire", "Ignited Minds", "India 2020"]
      }
    };

    const data = authorData[author];

    return (
      <div className="card mt-4 p-3">
        <h3>{author}</h3>
        <p>{data.bio}</p>
        <h5>Top Books</h5>
        <ul>
          {data.books.map((b, i) => (
            <li key={i}>{b}</li>
          ))}
        </ul>
      </div>
    );
  }
}

export default AuthorInfo;