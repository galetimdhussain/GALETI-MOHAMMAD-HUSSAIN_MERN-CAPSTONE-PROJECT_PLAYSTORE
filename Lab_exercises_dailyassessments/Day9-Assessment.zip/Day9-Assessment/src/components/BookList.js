import React, { useState, useRef } from "react";
import BookCard from "./BookCard";
import AuthorInfo from "./AuthorInfo";

function BookList() {

  const booksData = [
    { id: 1, title: "The Alchemist", author: "Paulo Coelho", price: 399 },
    { id: 2, title: "Atomic Habits", author: "James Clear", price: 499 },
    { id: 3, title: "Ikigai", author: "Hector Garcia", price: 299 },
    { id: 4, title: "Rich Dad Poor Dad", author: "Robert Kiyosaki", price: 450 },
    { id: 5, title: "Wings of Fire", author: "A.P.J Abdul Kalam", price: 350 },
    { id: 6, title: "Brida", author: "Paulo Coelho", price: 320 }
  ];

  const [viewMode, setViewMode] = useState("grid");
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedAuthor, setSelectedAuthor] = useState(null);

  const searchRef = useRef(null);

  const filteredBooks = booksData.filter(book =>
    book.title.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const focusSearch = () => {
    searchRef.current.focus();
  };

  return (
    <div className="container mt-4">

      <div className="d-flex justify-content-between align-items-center">
        <h2>Featured Books</h2>
        <button className="btn btn-primary" onClick={focusSearch}>
          Focus Search
        </button>
      </div>

      <input
        ref={searchRef}
        type="text"
        className="form-control mt-3"
        placeholder="Search books..."
        value={searchTerm}
        onChange={(e) => setSearchTerm(e.target.value)}
      />

      <div className="mt-3">
        <button className="btn btn-outline-secondary me-2" onClick={() => setViewMode("grid")}>
          Grid View
        </button>
        <button className="btn btn-outline-secondary" onClick={() => setViewMode("list")}>
          List View
        </button>
      </div>

      <div className={`row mt-4 ${viewMode === "list" ? "flex-column" : ""}`}>
        {filteredBooks.map(book => (
          <div className={viewMode === "grid" ? "col-md-4 mb-3" : "col-12"} key={book.id}>
            <BookCard
              title={book.title}
              author={book.author}
              price={book.price}
              viewMode={viewMode}
              onSelect={setSelectedAuthor}
            />
          </div>
        ))}
      </div>

      <AuthorInfo author={selectedAuthor} />
    </div>
  );
}

export default BookList;