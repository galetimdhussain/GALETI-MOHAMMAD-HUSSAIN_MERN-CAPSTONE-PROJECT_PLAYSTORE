import React from "react";
import PropTypes from "prop-types";

function BookCard({ title, author, price, viewMode, onSelect }) {
  return (
    <div
      className={`card p-3 ${viewMode === "grid" ? "" : "mb-2"}`}
      onClick={() => onSelect(author)}
      style={{ cursor: "pointer" }}
    >
      <h5 className="card-title">{title}</h5>
      <p className="card-text"><strong>Author:</strong> {author}</p>
      <p className="card-text text-success"><strong>Price:</strong> ₹{price}</p>
    </div>
  );
}

BookCard.propTypes = {
  title: PropTypes.string.isRequired,
  author: PropTypes.string.isRequired,
  price: PropTypes.number.isRequired,
  viewMode: PropTypes.string.isRequired,
  onSelect: PropTypes.func.isRequired
};

export default BookCard;