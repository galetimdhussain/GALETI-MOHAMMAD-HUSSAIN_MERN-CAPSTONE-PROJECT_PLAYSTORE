const { sequelize } = require("./src/config/env");

if (!sequelize.password || sequelize.password === "your_mysql_password") {
  throw new Error(
    "Set SEQUELIZE_DB_PASSWORD in .env to your real MySQL password before running sequelize migrations."
  );
}

module.exports = {
  development: {
    username: sequelize.user,
    password: sequelize.password,
    database: sequelize.database,
    host: sequelize.host,
    port: sequelize.port,
    dialect: "mysql",
  },
};
