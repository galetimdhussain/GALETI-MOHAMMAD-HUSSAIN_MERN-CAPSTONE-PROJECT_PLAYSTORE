CREATE DATABASE IF NOT EXISTS skillsphere;
USE skillsphere;

CREATE TABLE courses (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  title VARCHAR(150) NOT NULL,
  category VARCHAR(80) NOT NULL,
  level VARCHAR(50) NOT NULL,
  duration_hours INT UNSIGNED NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  INDEX idx_courses_category (category),
  INDEX idx_courses_level (level)
);