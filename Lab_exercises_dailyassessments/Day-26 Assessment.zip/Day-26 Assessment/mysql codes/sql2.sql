CREATE DATABASE IF NOT EXISTS skillsphere_orm;	
USE skillsphere_orm;
INSERT INTO instructors (name, email, expertise, createdAt, updatedAt)
VALUES (
  'Alex Morgan',
  'alex.morgan@skillsphere.dev',
  'Backend Engineering',
  NOW(),
  NOW()
);

INSERT INTO sequelize_courses (title, category, durationHours, instructorId, createdAt, updatedAt)
VALUES
  ('Express.js Foundations', 'Backend Development', 18, 1, NOW(), NOW()),
  ('Mastering Sequelize', 'Database Systems', 14, 1, NOW(), NOW());