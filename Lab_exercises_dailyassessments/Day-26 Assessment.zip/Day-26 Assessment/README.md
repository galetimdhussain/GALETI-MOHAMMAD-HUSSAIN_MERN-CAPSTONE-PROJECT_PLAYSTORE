# Day 26 - Database Connectivity

## Theme

Implementing persistent storage for SkillSphere using relational and NoSQL databases.

## Requirement Check

This project satisfies the Day 26 requirements.

### Challenge 1: MySQL Integration

- Uses `mysql2`
- Connects to MySQL using credentials from `.env`
- Inserts new course data into the `courses` table
- Prints console confirmation:
  `INSERT INTO courses successful. New course id: <id>`

File used:
- `src/mysql/insertCourse.js`

### Challenge 2: MongoDB Integration

- Uses `mongoose`
- Defines `User` model
- Defines `Enrollment` model
- Fetches enrollment details
- Populates user information from MongoDB
- Displays results in the console using `console.table`

Files used:
- `src/mongodb/models/User.js`
- `src/mongodb/models/Enrollment.js`
- `src/mongodb/fetchEnrollmentDetails.js`

### Challenge 3: Sequelize ORM

- Uses `sequelize`
- Defines `Instructor` model
- Defines `Course` model
- Implements One-to-Many relationship:
  `Instructor -> Courses`
- Retrieves all courses by instructor email

Files used:
- `src/sequelize/models/Instructor.js`
- `src/sequelize/models/Course.js`
- `src/sequelize/models/index.js`
- `src/sequelize/queryInstructorCourses.js`

### Best Practices Covered

- Database credentials are stored in `.env`
- Sequelize migration is included for schema evolution
- Indexes are used in MySQL, MongoDB, and Sequelize models
- SQL structure is normalized using foreign keys
- MongoDB keeps enrollment data flexible while referencing users

## Project Setup

### 1. Install dependencies

Run:

```bash
npm install
```

### 2. Create `.env`

Create a `.env` file in the project root with your real database credentials:

```env
MYSQL_HOST=localhost
MYSQL_PORT=3306
MYSQL_USER=root
MYSQL_PASSWORD=your_mysql_password
MYSQL_DATABASE=skillsphere

MONGODB_URI=mongodb://127.0.0.1:27017/skillsphere

SEQUELIZE_DB_HOST=localhost
SEQUELIZE_DB_PORT=3306
SEQUELIZE_DB_USER=root
SEQUELIZE_DB_PASSWORD=your_mysql_password
SEQUELIZE_DB_NAME=skillsphere_orm

DEFAULT_INSTRUCTOR_EMAIL=alex.morgan@skillsphere.dev
```

## Database Creation Steps

### 3. Create MySQL database for Challenge 1

Open MySQL and run:

```sql
CREATE DATABASE IF NOT EXISTS skillsphere;
USE skillsphere;

CREATE TABLE courses (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  title VARCHAR(150) NOT NULL,
  category VARCHAR(80) NOT NULL,
  level VARCHAR(50) NOT NULL,
  duration_hours INT UNSIGNED NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  INDEX idx_courses_category (category),
  INDEX idx_courses_level (level)
);
```

### 4. Create MongoDB database for Challenge 2

Open `mongosh` and run:

```javascript
use skillsphere

db.users.insertOne({
  name: "Priya Sharma",
  email: "priya@skillsphere.dev",
  role: "student"
})
```

Copy the inserted `_id`, then run:

```javascript
db.enrollments.insertMany([
  {
    user: ObjectId("PASTE_USER_ID_HERE"),
    courseTitle: "Node.js API Mastery",
    status: "active",
    enrolledAt: new Date()
  },
  {
    user: ObjectId("PASTE_USER_ID_HERE"),
    courseTitle: "SQL for Developers",
    status: "completed",
    enrolledAt: new Date()
  }
])
```

### 5. Create MySQL database for Challenge 3

Open MySQL and run:

```sql
CREATE DATABASE IF NOT EXISTS skillsphere_orm;
```

Run migration:

```bash
npm run sequelize:migrate
```

Then add instructor and courses manually:

```sql
USE skillsphere_orm;

INSERT INTO instructors (name, email, expertise, createdAt, updatedAt)
VALUES (
  'Alex Morgan',
  'alex.morgan@skillsphere.dev',
  'Backend Engineering',
  NOW(),
  NOW()
);

INSERT INTO sequelize_courses (title, category, durationHours, instructorId, createdAt, updatedAt)
VALUES
  ('Express.js Foundations', 'Backend Development', 18, 1, NOW(), NOW()),
  ('Mastering Sequelize', 'Database Systems', 14, 1, NOW(), NOW());
```

If your instructor id is not `1`, use the actual id in `sequelize_courses`.

## Commands To Run

### Challenge 1

```bash
npm run mysql:insert
```

Expected output:

```text
INSERT INTO courses successful. New course id: <number>
```

### Challenge 2

```bash
npm run mongo:fetch
```

Expected output:

- Enrollment details table in console
- Populated user name, email, role, course title, status, and enrolled date

### Challenge 3

```bash
npm run sequelize:query
```

Expected output:

- Courses by `Alex Morgan`
- All courses belonging to that instructor displayed in table format

## Screenshots To Take For Submission

Take these screenshots clearly.

### Screenshot 1

- MySQL `skillsphere` database created
- `courses` table created

### Screenshot 2

- Terminal output of:
  `npm run mysql:insert`
- Must show:
  `INSERT INTO courses successful. New course id: ...`

### Screenshot 3

- MongoDB `users` collection with inserted user
- MongoDB `enrollments` collection with inserted enrollment records

### Screenshot 4

- Terminal output of:
  `npm run mongo:fetch`
- Must show fetched enrollment details

### Screenshot 5

- Terminal output of:
  `npm run sequelize:migrate`
- Must show migration completed successfully

### Screenshot 6

- MySQL `skillsphere_orm` database
- `instructors` table
- `sequelize_courses` table
- Inserted instructor and courses

### Screenshot 7

- Terminal output of:
  `npm run sequelize:query`
- Must show all courses for the instructor

## Suggested Submission Order

1. Show `.env` file exists but hide the password when taking screenshot.
2. Show MySQL database and `courses` table.
3. Run `npm run mysql:insert`.
4. Show MongoDB collections.
5. Run `npm run mongo:fetch`.
6. Run `npm run sequelize:migrate`.
7. Show `instructors` and `sequelize_courses` tables.
8. Run `npm run sequelize:query`.

## Final Confirmation

Yes, this project now meets the Day 26 problem statement requirements:

- MySQL insert using `mysql2`
- MongoDB models and data retrieval using `mongoose`
- Sequelize ORM models and one-to-many relationship
- Query to get all courses by instructor
- `.env` based credentials
- migration support
- indexes included
