const { createMySqlPool } = require("../config/mysql");

async function insertCourse(courseInput = {}) {
  const pool = createMySqlPool();

  const course = {
    title: courseInput.title || "Database Fundamentals",
    category: courseInput.category || "Backend Development",
    level: courseInput.level || "Intermediate",
    duration_hours: courseInput.duration_hours || 24,
  };

  const sql = `
    INSERT INTO courses (title, category, level, duration_hours)
    VALUES (?, ?, ?, ?)
  `;

  try {
    const [result] = await pool.execute(sql, [
      course.title,
      course.category,
      course.level,
      course.duration_hours,
    ]);

    console.log(
      `INSERT INTO courses successful. New course id: ${result.insertId}`
    );

    return result;
  } finally {
    await pool.end();
  }
}

if (require.main === module) {
  insertCourse().catch((error) => {
    console.error("MySQL insert failed:", error.message);
    process.exitCode = 1;
  });
}

module.exports = {
  insertCourse,
};
