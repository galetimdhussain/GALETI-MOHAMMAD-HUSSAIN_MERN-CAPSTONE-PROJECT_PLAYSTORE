const { defaults } = require("../config/env");
const { sequelize, Instructor, Course } = require("./models");

async function queryCoursesByInstructor(email = defaults.instructorEmail) {
  await sequelize.authenticate();

  const instructor = await Instructor.findOne({
    where: { email },
    include: [
      {
        model: Course,
        as: "courses",
      },
    ],
    order: [[{ model: Course, as: "courses" }, "title", "ASC"]],
  });

  if (!instructor) {
    console.log(`No instructor found for email: ${email}`);
    return [];
  }

  const results = instructor.courses.map((course) => ({
    instructor: instructor.name,
    email: instructor.email,
    title: course.title,
    category: course.category,
    durationHours: course.durationHours,
  }));

  console.log(`Courses by ${instructor.name}:`);
  console.table(results);
  return results;
}

if (require.main === module) {
  queryCoursesByInstructor()
    .catch((error) => {
      console.error("Sequelize query failed:", error.message);
      process.exitCode = 1;
    })
    .finally(async () => {
      await sequelize.close();
    });
}

module.exports = {
  queryCoursesByInstructor,
};
