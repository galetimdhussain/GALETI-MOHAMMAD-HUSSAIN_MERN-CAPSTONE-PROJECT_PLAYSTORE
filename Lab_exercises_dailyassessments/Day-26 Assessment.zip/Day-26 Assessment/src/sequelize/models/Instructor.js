const { DataTypes, Model } = require("sequelize");

class Instructor extends Model {}

function initInstructor(sequelize) {
  Instructor.init(
    {
      id: {
        type: DataTypes.INTEGER.UNSIGNED,
        autoIncrement: true,
        primaryKey: true,
      },
      name: {
        type: DataTypes.STRING(120),
        allowNull: false,
      },
      email: {
        type: DataTypes.STRING(160),
        allowNull: false,
        unique: true,
      },
      expertise: {
        type: DataTypes.STRING(120),
        allowNull: false,
      },
    },
    {
      sequelize,
      modelName: "Instructor",
      tableName: "instructors",
      indexes: [
        {
          unique: true,
          fields: ["email"],
        },
      ],
    }
  );

  return Instructor;
}

module.exports = {
  Instructor,
  initInstructor,
};
