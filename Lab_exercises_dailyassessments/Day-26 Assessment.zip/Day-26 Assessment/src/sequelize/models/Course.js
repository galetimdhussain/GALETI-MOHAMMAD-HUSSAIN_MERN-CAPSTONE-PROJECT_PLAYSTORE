const { DataTypes, Model } = require("sequelize");

class Course extends Model {}

function initCourse(sequelize) {
  Course.init(
    {
      id: {
        type: DataTypes.INTEGER.UNSIGNED,
        autoIncrement: true,
        primaryKey: true,
      },
      title: {
        type: DataTypes.STRING(150),
        allowNull: false,
      },
      category: {
        type: DataTypes.STRING(80),
        allowNull: false,
      },
      durationHours: {
        type: DataTypes.INTEGER.UNSIGNED,
        allowNull: false,
      },
      instructorId: {
        type: DataTypes.INTEGER.UNSIGNED,
        allowNull: false,
      },
    },
    {
      sequelize,
      modelName: "Course",
      tableName: "sequelize_courses",
      indexes: [
        {
          fields: ["instructorId"],
        },
        {
          fields: ["category"],
        },
      ],
    }
  );

  return Course;
}

module.exports = {
  Course,
  initCourse,
};
