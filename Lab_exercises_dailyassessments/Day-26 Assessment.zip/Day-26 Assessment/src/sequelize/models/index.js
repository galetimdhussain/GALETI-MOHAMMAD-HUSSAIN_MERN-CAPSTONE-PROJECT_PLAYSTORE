const sequelize = require("../../config/sequelize");
const { Instructor, initInstructor } = require("./Instructor");
const { Course, initCourse } = require("./Course");

initInstructor(sequelize);
initCourse(sequelize);

Instructor.hasMany(Course, {
  foreignKey: "instructorId",
  as: "courses",
});

Course.belongsTo(Instructor, {
  foreignKey: "instructorId",
  as: "instructor",
});

module.exports = {
  sequelize,
  Instructor,
  Course,
};
