const fs = require("fs");
const path = require("path");
const dotenv = require("dotenv");

const envPath = path.resolve(process.cwd(), ".env");

if (!fs.existsSync(envPath)) {
  throw new Error(
    "Missing .env file. Create .env in the project root using .env.example before running database commands."
  );
}

dotenv.config({
  path: envPath,
  override: true,
});

function readNumber(value, fallback) {
  const parsed = Number(value);
  return Number.isFinite(parsed) ? parsed : fallback;
}

module.exports = {
  mysql: {
    host: process.env.MYSQL_HOST || "localhost",
    port: readNumber(process.env.MYSQL_PORT, 3306),
    user: process.env.MYSQL_USER || "root",
    password: process.env.MYSQL_PASSWORD || "",
    database: process.env.MYSQL_DATABASE || "skillsphere",
  },
  mongo: {
    uri: process.env.MONGODB_URI || "mongodb://127.0.0.1:27017/skillsphere",
  },
  sequelize: {
    host: process.env.SEQUELIZE_DB_HOST || process.env.MYSQL_HOST || "localhost",
    port: readNumber(process.env.SEQUELIZE_DB_PORT || process.env.MYSQL_PORT, 3306),
    user: process.env.SEQUELIZE_DB_USER || process.env.MYSQL_USER || "root",
    password: process.env.SEQUELIZE_DB_PASSWORD || process.env.MYSQL_PASSWORD || "",
    database: process.env.SEQUELIZE_DB_NAME || "skillsphere_orm",
  },
  defaults: {
    instructorEmail: process.env.DEFAULT_INSTRUCTOR_EMAIL || "alex.morgan@skillsphere.dev",
  },
};
