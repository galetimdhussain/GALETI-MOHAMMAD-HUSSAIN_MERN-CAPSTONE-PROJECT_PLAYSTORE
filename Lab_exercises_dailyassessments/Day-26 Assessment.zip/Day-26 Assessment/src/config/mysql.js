const mysql = require("mysql2/promise");
const { mysql: mysqlConfig } = require("./env");

function createMySqlPool() {
  return mysql.createPool({
    ...mysqlConfig,
    waitForConnections: true,
    connectionLimit: 10,
    queueLimit: 0,
  });
}

module.exports = {
  createMySqlPool,
};
