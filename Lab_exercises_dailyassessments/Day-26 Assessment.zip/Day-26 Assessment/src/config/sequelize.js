const { Sequelize } = require("sequelize");
const { sequelize: sequelizeConfig } = require("./env");

const sequelize = new Sequelize(
  sequelizeConfig.database,
  sequelizeConfig.user,
  sequelizeConfig.password,
  {
    host: sequelizeConfig.host,
    port: sequelizeConfig.port,
    dialect: "mysql",
    logging: false,
  }
);

module.exports = sequelize;
