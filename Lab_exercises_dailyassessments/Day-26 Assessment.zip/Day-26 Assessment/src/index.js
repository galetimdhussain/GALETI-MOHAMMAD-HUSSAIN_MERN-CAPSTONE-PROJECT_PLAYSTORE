const { insertCourse } = require("./mysql/insertCourse");
const { fetchEnrollmentDetails } = require("./mongodb/fetchEnrollmentDetails");
const { queryCoursesByInstructor } = require("./sequelize/queryInstructorCourses");

module.exports = {
  insertCourse,
  fetchEnrollmentDetails,
  queryCoursesByInstructor,
};
