const { connectMongo, disconnectMongo } = require("../config/mongo");
const User = require("./models/User");
const Enrollment = require("./models/Enrollment");

async function fetchEnrollmentDetails() {
  await connectMongo();

  try {
    const enrollments = await Enrollment.find({})
      .populate({
        path: "user",
        model: User,
        select: "name email role",
      })
      .sort({ enrolledAt: -1 })
      .lean();

    console.log("Enrollment details:");
    console.table(
      enrollments.map((enrollment) => ({
        enrollmentId: String(enrollment._id),
        studentName: enrollment.user?.name || "Unknown",
        email: enrollment.user?.email || "Unknown",
        role: enrollment.user?.role || "Unknown",
        courseTitle: enrollment.courseTitle,
        status: enrollment.status,
        enrolledAt: enrollment.enrolledAt,
      }))
    );

    return enrollments;
  } finally {
    await disconnectMongo();
  }
}

if (require.main === module) {
  fetchEnrollmentDetails().catch((error) => {
    console.error("MongoDB fetch failed:", error.message);
    process.exitCode = 1;
  });
}

module.exports = {
  fetchEnrollmentDetails,
};
