import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';

// Mock API call
export const fetchProducts = createAsyncThunk('products/fetchProducts', async () => {
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve([
        { id: 1, name: 'Yoga Mat', price: 20 },
        { id: 2, name: 'Dumbbells (5kg)', price: 45 },
        { id: 3, name: 'Protein Powder', price: 60 }
      ]);
    }, 1000);
  });
});

const productSlice = createSlice({
  name: 'products',
  initialState: {
    items: [],
    status: 'idle', // idle | loading | succeeded | failed
  },
  reducers: {
    updateProduct: (state, action) => {
      const { id, name, price } = action.payload;
      const existingProduct = state.items.find(product => product.id === id);
      if (existingProduct) {
        if (name !== undefined) existingProduct.name = name;
        if (price !== undefined) existingProduct.price = price;
      }
    }
  },
  extraReducers: (builder) => {
    builder
      .addCase(fetchProducts.pending, (state) => { state.status = 'loading'; })
      .addCase(fetchProducts.fulfilled, (state, action) => {
        state.status = 'succeeded';
        state.items = action.payload;
      });
  }
});

export const { updateProduct } = productSlice.actions;
export default productSlice.reducer;