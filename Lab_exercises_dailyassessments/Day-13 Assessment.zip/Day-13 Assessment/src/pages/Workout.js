import React, { useState } from "react";
import useTimer from "../hooks/useTimer";

function Workout() {

  const [sets, setSets] = useState(0);
  const [running, setRunning] = useState(false);

  const { seconds, reset } = useTimer(running);

  const start = () => setRunning(true);
  const stop = () => setRunning(false);

  const nextSet = () => {
    setSets(prev => prev + 1);
    reset();
  };

  return (
    <div className="container mt-4">
      <h2>Workout Tracker</h2>

      <p>Sets Completed: {sets}</p>
      <p>Rest Timer: {seconds} sec</p>

      <button className="btn btn-success me-2" onClick={start}>
        Start
      </button>

      <button className="btn btn-danger me-2" onClick={stop}>
        Stop
      </button>

      <button className="btn btn-primary" onClick={nextSet}>
        Next Set
      </button>
    </div>
  );
}

export default Workout;