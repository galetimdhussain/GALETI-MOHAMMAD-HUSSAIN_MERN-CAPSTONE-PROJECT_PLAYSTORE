import React, { useEffect } from "react";
import { useSelector, useDispatch } from "react-redux";
import { fetchProducts, updateProduct } from "../redux/productSlice";

function Products() {

  const dispatch = useDispatch();
  const { items, status } = useSelector(state => state.products);

  useEffect(() => {
    dispatch(fetchProducts());
  }, [dispatch]);

  const modify = (product) => {
    dispatch(updateProduct({ ...product, title: product.title + " Updated" }));
  };

  return (
    <div className="container mt-4">
      <h2>Products</h2>

      {status === "loading" && <p>Loading...</p>}

      {items.map(product => (
        <div key={product.id} className="card p-2 mb-2">
          <h5>{product.title}</h5>
          <button className="btn btn-sm btn-warning"
                  onClick={() => modify(product)}>
            Update
          </button>
        </div>
      ))}
    </div>
  );
}

export default Products;