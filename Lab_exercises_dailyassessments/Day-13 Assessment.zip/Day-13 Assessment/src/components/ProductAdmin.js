import React, { useEffect } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { fetchProducts, updateProduct } from '../redux/productSlice';

const ProductAdmin = () => {
  const dispatch = useDispatch();
  const { items, status } = useSelector((state) => state.products);

  useEffect(() => {
    if (status === 'idle') {
      dispatch(fetchProducts());
    }
  }, [status, dispatch]);

  const handlePriceIncrease = (id, currentPrice, currentName) => {
    dispatch(updateProduct({ id, name: currentName, price: currentPrice + 5 }));
  };

  return (
    <div className="card">
      <h2>Product Admin (Redux)</h2>
      {status === 'loading' && <p>Loading products...</p>}
      <div className="product-list">
        {items.map((product) => (
          <div key={product.id} className="product-item">
            <span>{product.name}</span>
            <strong>${product.price}</strong>
            <button onClick={() => handlePriceIncrease(product.id, product.price, product.name)}>+ $5</button>
          </div>
        ))}
      </div>
    </div>
  );
};

export default ProductAdmin;