import React, { useState } from 'react';
import useTimer from '../hooks/useTimer';

const WorkoutTracker = () => {
  const [sets, setSets] = useState(0);
  const { time, isRunning, start, stop, reset } = useTimer(0);

  const formatTime = (seconds) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs < 10 ? '0' : ''}${secs}`;
  };

  return (
    <div className="card">
      <h2>Workout Tracker</h2>
      <div className="stats">
        <p><strong>Sets Completed:</strong> {sets}</p>
        <button className="btn-primary" onClick={() => setSets(sets + 1)}>+ Add Set</button>
        <button className="btn-danger" style={{marginLeft: '10px'}} onClick={() => setSets(0)}>Reset Sets</button>
      </div>
      
      <div className="timer-section">
        <h3>Rest Timer</h3>
        <div className="timer-display">{formatTime(time)}</div>
        {!isRunning ? <button className="btn-success" onClick={start}>Start Rest</button> : <button className="btn-danger" onClick={stop}>Stop</button>}
        <button style={{marginLeft: '10px'}} onClick={reset}>Reset Timer</button>
      </div>
    </div>
  );
};

export default WorkoutTracker;