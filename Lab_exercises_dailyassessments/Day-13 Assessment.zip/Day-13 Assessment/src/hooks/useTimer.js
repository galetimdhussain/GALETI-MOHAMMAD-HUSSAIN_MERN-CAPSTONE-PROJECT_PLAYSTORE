import { useState, useEffect, useRef } from 'react';

const useTimer = (initialState = 0) => {
  const [time, setTime] = useState(initialState);
  const [isRunning, setIsRunning] = useState(false);
  const intervalRef = useRef(null);

  useEffect(() => {
    if (isRunning) {
      intervalRef.current = setInterval(() => {
        setTime((prev) => prev + 1);
      }, 1000);
    } else {
      clearInterval(intervalRef.current);
    }
    return () => clearInterval(intervalRef.current);
  }, [isRunning]);

  const start = () => setIsRunning(true);
  const stop = () => setIsRunning(false);
  const reset = () => { setIsRunning(false); setTime(0); };

  return { time, isRunning, start, stop, reset };
};

export default useTimer;