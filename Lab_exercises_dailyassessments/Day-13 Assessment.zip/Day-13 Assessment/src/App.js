import React, { useState, useEffect } from 'react';
import { useTheme } from './context/ThemeContext';
import WorkoutTracker from './components/WorkoutTracker';
import ProductAdmin from './components/ProductAdmin';
import './App.css';

const OfflineBanner = () => (
  <div className="offline-banner">
    ⚠️ You are currently offline. App is running in offline mode.
  </div>
);

function App() {
  const { theme, toggleTheme } = useTheme();
  const [isOnline, setIsOnline] = useState(navigator.onLine);

  useEffect(() => {
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  return (
    <div className="app-container">
      {!isOnline && <OfflineBanner />}
      <header>
        <h1>Hussain Fitness & Workout tracker</h1>
        <button onClick={toggleTheme}>
          Switch to {theme === 'light' ? 'Dark' : 'Light'} Mode
        </button>
      </header>
      <WorkoutTracker />
      <ProductAdmin />
    </div>
  );
}

export default App;