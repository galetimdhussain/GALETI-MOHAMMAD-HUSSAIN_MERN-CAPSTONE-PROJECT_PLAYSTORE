Hussain Fitness & workout tracker

Overview

This project is a React application built to demonstrate advanced concepts like the Context API, Redux Toolkit, Custom Hooks, and Progressive Web App (PWA) capabilities. It functions as a fitness tracker and a product management dashboard.

Features and Implementation

1. Theme Management (Context API)
I implemented a global theme system to switch between Light and Dark modes. Instead of passing props down manually, I used the React Context API.
*   **How it works:** The `ThemeContext` wraps the application and provides the current theme value.
*   **Persistence:** I used `localStorage` inside the provider so that the user's preference is saved even if they refresh the page.

2. Workout Tracker (React Hooks)
This feature allows users to track their workout sets and rest times.
*   **Custom Hook:** I abstracted the timer logic into a custom hook called `useTimer`. This hook manages the interval and time state.
*   **State Management:** The component uses `useState` to keep track of the number of sets completed. `useEffect` is used within the hook to handle the ticking timer and cleanup.

3. Product Admin (Redux Toolkit)
I used Redux Toolkit to manage the product data globally. This simulates an admin dashboard where product prices can be updated.
*   **Global Store:** The `productSlice` manages the state for items and loading status.
*   **Async Operations:** I used `createAsyncThunk` to simulate fetching data from an API with a delay.
*   **Updates:** Actions are dispatched to update product prices, and these changes are reflected immediately in the UI without local component state.

4. Progressive Web App (PWA)
The app is configured to work offline and can be installed on a device.
*   **Service Worker:** A `sw.js` file caches key resources to ensure the app loads even without an internet connection.
*   **Manifest:** The `manifest.json` file provides metadata like icons and the app name, making it installable.
*   **Offline Support:** I added a listener for network status. If the internet connection is lost, an "Offline" banner appears at the top of the screen.

Dependencies

*   `react`
*   `react-dom`
*   `react-scripts`
*   `@reduxjs/toolkit`
*   `react-redux`

How to Run

1.  Install the dependencies:

    npm install

2.  Start the development server:

    npm start

3.  Open your browser to `http://localhost:3000`.
