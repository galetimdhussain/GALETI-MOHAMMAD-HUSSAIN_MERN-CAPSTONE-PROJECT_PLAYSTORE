const express = require("express");
const userRouter = require("./routes/users");

const app = express();
const PORT = 4000;

// view engine setup
app.set("view engine", "ejs");
app.set("views", "views");

// global logging middleware
app.use((req, res, next) => {
    const timestamp = new Date().toISOString();
    console.log(`[${req.method}] ${req.url} at ${timestamp}`);
    next();
});

// built in middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// sample course data
const courses = [
    { id: 101, name: "React Mastery", duration: "6 weeks" },
    { id: 102, name: "Node.js Essentials", duration: "4 weeks" },
    { id: 103, name: "MongoDB Basics", duration: "3 weeks" }
];

// home route
app.get("/", (req, res) => {
    res.send("SkillSphere LMS API running");
});

// template rendering
app.get("/courses", (req, res) => {
    res.render("courses", { courses: courses });
});

// user routes
app.use("/users", userRouter);

app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
});