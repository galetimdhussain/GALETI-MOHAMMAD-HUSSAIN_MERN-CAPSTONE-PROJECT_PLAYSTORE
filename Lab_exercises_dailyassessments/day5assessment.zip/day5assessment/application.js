const postsContainer = document.getElementById("postsContainer");
const todosContainer = document.getElementById("todosContainer");

const blogLoading = document.getElementById("blogLoading");
const todoLoading = document.getElementById("todoLoading");

const blogError = document.getElementById("blogError");
const todoError = document.getElementById("todoError");


fetch("https://jsonplaceholder.typicode.com/posts")
    .then(response => {
        if (!response.ok) {
            throw new Error("Failed to fetch posts");
        }
        return response.json();
    })
    .then(data => {
        blogLoading.style.display = "none";

        data.slice(0, 10).forEach(post => {
            const div = document.createElement("div");
            div.className = "post";

            div.innerHTML = `
                <h3>${post.title}</h3>
                <p>${post.body}</p>
            `;

            postsContainer.appendChild(div);
        });
    })
    .catch(error => {
        blogLoading.style.display = "none";
        blogError.textContent = error.message;
    });



fetch("https://jsonplaceholder.typicode.com/todos")
    .then(response => {
        if (!response.ok) {
            throw new Error("Failed to fetch todos");
        }
        return response.json();
    })
    .then(data => {
        todoLoading.style.display = "none";

        data.slice(0, 15).forEach(todo => {
            const div = document.createElement("div");
            div.className = "todo";

            const checkbox = document.createElement("input");
            checkbox.type = "checkbox";
            checkbox.checked = todo.completed;

            const span = document.createElement("span");
            span.textContent = todo.title;

            if (todo.completed) {
                span.classList.add("completed");
            }

            checkbox.addEventListener("change", () => {
                span.classList.toggle("completed");
            });

            div.appendChild(checkbox);
            div.appendChild(span);
            todosContainer.appendChild(div);
        });
    })
    .catch(error => {
        todoLoading.style.display = "none";
        todoError.textContent = error.message;
    });