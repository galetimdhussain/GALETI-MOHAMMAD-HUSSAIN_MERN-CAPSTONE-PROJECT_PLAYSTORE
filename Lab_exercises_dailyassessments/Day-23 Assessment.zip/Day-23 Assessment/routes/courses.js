const express = require("express");
const { body, validationResult } = require("express-validator");

const router = express.Router();

let courses = [
    { id: 1, name: "NodeJS", duration: "4 weeks" },
    { id: 2, name: "React", duration: "6 weeks" }
];

router.get("/", (req, res) => {
    res.json(courses);
});

router.post(
    "/",
    [
        body("name").notEmpty().withMessage("Course name is required"),
        body("duration").notEmpty().withMessage("Course duration is required")
    ],
    (req, res, next) => {

        const errors = validationResult(req);

        if (!errors.isEmpty()) {
            return res.status(400).json({ error: errors.array()[0].msg });
        }

        const newCourse = {
            id: courses.length + 1,
            name: req.body.name,
            duration: req.body.duration
        };

        courses.push(newCourse);

        res.json(newCourse);
    }
);

router.put("/:id", (req, res) => {

    const id = parseInt(req.params.id);

    const course = courses.find(c => c.id === id);

    if (!course) {
        return res.status(404).json({ error: "Course not found" });
    }

    course.name = req.body.name || course.name;
    course.duration = req.body.duration || course.duration;

    res.json(course);
});

router.delete("/:id", (req, res) => {

    const id = parseInt(req.params.id);

    const index = courses.findIndex(c => c.id === id);

    if (index === -1) {
        return res.status(404).json({ error: "Course not found" });
    }

    const deleted = courses.splice(index, 1);

    res.json(deleted[0]);
});

module.exports = router;