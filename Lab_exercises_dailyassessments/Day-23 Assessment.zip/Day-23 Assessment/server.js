const express = require("express");
const rateLimit = require("express-rate-limit");

const courseRoutes = require("./routes/courses");
const errorHandler = require("./middleware/errorHandler");

const app = express();

app.use(express.json());

const limiter = rateLimit({
    windowMs: 60 * 1000,
    max: 5,
    message: { error: "Too many requests" }
});

app.use(limiter);

app.use("/api/v1/courses", courseRoutes);

app.use(errorHandler);

app.listen(3000, () => {
    console.log("Server running on port 3000");
});