const express = require("express");
const multer = require("multer");
const path = require("path");
const fs = require("fs");
const http = require("http");
const { Server } = require("socket.io");

const app = express();
const server = http.createServer(app);
const io = new Server(server);
const uploadsDir = path.join(__dirname, "uploads");

app.use(express.json());

if (!fs.existsSync(uploadsDir)) {
  fs.mkdirSync(uploadsDir, { recursive: true });
}

app.use(
  "/materials",
  express.static(uploadsDir, {
    setHeaders: (res, filePath) => {
      res.setHeader(
        "Content-Disposition",
        `attachment; filename="${path.basename(filePath)}"`
      );
    },
  })
);

app.use(express.static(path.join(__dirname, "public")));

const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, uploadsDir);
  },
  filename: function (req, file, cb) {
    const parsed = path.parse(file.originalname);
    const safeBase = parsed.name.replace(/[^a-zA-Z0-9_-]/g, "_");
    const safeExt = parsed.ext.toLowerCase();
    const candidateName = `${safeBase}${safeExt}`;
    const targetPath = path.join(uploadsDir, candidateName);

    if (fs.existsSync(targetPath)) {
      fs.unlinkSync(targetPath);
    }

    cb(null, candidateName);
  },
});

const fileFilter = (req, file, cb) => {
  const allowedMimes = new Set([
    "application/pdf",
    "application/x-pdf",
    "application/octet-stream",
  ]);
  const isPdfMime = allowedMimes.has(file.mimetype);
  const isPdfExt = path.extname(file.originalname).toLowerCase() === ".pdf";

  if (isPdfMime && isPdfExt) {
    cb(null, true);
  } else {
    cb(new Error("Only PDF files allowed"), false);
  }
};

const upload = multer({
  storage: storage,
  fileFilter: fileFilter,
  limits: { fileSize: 10 * 1024 * 1024 },
});

app.post("/upload", (req, res) => {
  upload.single("file")(req, res, (err) => {
    if (err) {
      return res.status(400).send(err.message);
    }

    if (!req.file) {
      return res
        .status(400)
        .send('No file uploaded. Use form-data field name "file".');
    }

    res.send("File uploaded successfully: " + req.file.filename);
  });
});

io.on("connection", (socket) => {
  console.log("User connected");

  socket.on("chat message", (msg) => {
    const text = String(msg || "").trim();
    if (!text) {
      return;
    }
    io.emit("chat message", text);
  });

  socket.on("disconnect", () => {
    console.log("User disconnected");
  });
});

server.listen(3000, () => {
  console.log("Server running on port 3000");
});
