const productContainer = document.getElementById("productContainer");
const categoryFilter = document.getElementById("categoryFilter");
const sortFilter =
  document.getElementById("sortFilter") || document.getElementById("priceSort");
const loadingElement =
  document.getElementById("loadingMessage") || document.getElementById("loading");
const errorElement = document.getElementById("errorMessage");

const newsletterForm = document.getElementById("newsletterForm");
const newsletterEmail = document.getElementById("newsletterEmail");
const newsletterMessage = document.getElementById("newsletterMessage");

const INR_MULTIPLIER = 100;
const pagePath = window.location.pathname.toLowerCase();
const productsUrl = pagePath.includes("/userstory1/")
  ? "../userstory2/products.json"
  : "./products.json";
const fallbackImage = pagePath.includes("/userstory1/")
  ? "./no-image.svg"
  : "../userstory1/no-image.svg";

const fallbackProducts = [
  {
    id: 1,
    name: "Fjallraven Backpack",
    category: "Fashion",
    price: 109.95,
    image: "https://source.unsplash.com/900x600/?backpack"
  },
  {
    id: 2,
    name: "WD 2TB External Hard Drive",
    category: "Electronics",
    price: 64,
    image: "https://source.unsplash.com/900x600/?external-hard-drive"
  },
  {
    id: 3,
    name: "Samsung 49 inch Curved Monitor",
    category: "Electronics",
    price: 999.99,
    image: "https://source.unsplash.com/900x600/?curved-monitor"
  },
  {
    id: 4,
    name: "Pierced Owl Rose Gold Plated",
    category: "Jewellery",
    price: 10.99,
    image: "https://source.unsplash.com/900x600/?rose-gold-earrings"
  }
];

let allProducts = [];

document.addEventListener("DOMContentLoaded", () => {
  if (newsletterForm && newsletterEmail && newsletterMessage) {
    setupNewsletterValidation();
  }

  if (categoryFilter && sortFilter && productContainer) {
    fetchProducts();
    categoryFilter.addEventListener("change", applyFilterAndSort);
    sortFilter.addEventListener("change", applyFilterAndSort);
  }
});

function setupNewsletterValidation() {
  newsletterForm.addEventListener("submit", function (event) {
    event.preventDefault();

    const emailValue = newsletterEmail.value.trim();
    const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

    if (emailPattern.test(emailValue)) {
      newsletterMessage.textContent = "Subscribed successfully.";
      newsletterMessage.style.color = "#198754";
      newsletterForm.reset();
    } else {
      newsletterMessage.textContent = "Please enter a valid email.";
      newsletterMessage.style.color = "#dc3545";
    }
  });
}

async function fetchProducts() {
  showLoading(true); 
  showError("");

  try {
    const response = await fetch(productsUrl);
    if (!response.ok) {
      throw new Error("Unable to read product data.");
    }

    allProducts = await response.json();
    populateCategoryList(allProducts);
    renderProducts(allProducts);
  } catch (error) {
    allProducts = fallbackProducts;
    showError("JSON fetch failed. Showing fallback products.");
    populateCategoryList(allProducts);
    renderProducts(allProducts);
  } finally {
    showLoading(false);
  }
}

function populateCategoryList(products) {
  if (!categoryFilter) {
    return;
  }

  categoryFilter.innerHTML = '<option value="all">All Categories</option>';

  const uniqueCategories = [...new Set(products.map((item) => item.category))];
  for (const category of uniqueCategories) {
    const option = document.createElement("option");
    option.value = category;
    option.textContent = category;
    categoryFilter.appendChild(option);
  }
}

function applyFilterAndSort() {
  const selectedCategory = categoryFilter.value;
  const selectedSort = sortFilter.value;

  let filteredProducts = [...allProducts];

  if (selectedCategory !== "all") {
    filteredProducts = filteredProducts.filter(
      (item) => item.category === selectedCategory
    );
  }

  if (selectedSort === "asc" || selectedSort === "low-to-high") {
    filteredProducts.sort((a, b) => convertToRupees(a.price) - convertToRupees(b.price));
  }

  if (selectedSort === "desc" || selectedSort === "high-to-low") {
    filteredProducts.sort((a, b) => convertToRupees(b.price) - convertToRupees(a.price));
  }

  renderProducts(filteredProducts);
}

function renderProducts(products) {
  productContainer.innerHTML = "";

  if (products.length === 0) {
    productContainer.innerHTML =
      '<div class="col-12"><p class="mb-0">No matching products found.</p></div>';
    return;
  }

  for (const product of products) {
    const rupeePrice = convertToRupees(product.price);

    const cardColumn = document.createElement("div");
    cardColumn.className = "col-sm-6 col-lg-4 mb-3";
    cardColumn.innerHTML = `
      <article class="card product-card h-100">
        <img src="${product.image}" class="card-img-top" alt="${product.name}" onerror="this.src='${fallbackImage}';">
        <div class="card-body">
          <h3 class="h6 card-title">${product.name}</h3>
          <p class="card-text mb-1">Category: ${product.category}</p>
          <p class="card-text mb-0">Price: Rs. ${rupeePrice.toFixed(2)}</p>
        </div>
      </article>
    `;

    productContainer.appendChild(cardColumn);
  }
}

function convertToRupees(dollarValue) {
  return Number(dollarValue) * INR_MULTIPLIER;
}

function showLoading(isLoading) {
  if (!loadingElement) {
    return;
  }
  loadingElement.style.display = isLoading ? "block" : "none";
}

function showError(message) {
  if (errorElement) {
    errorElement.textContent = message;
  }
}
