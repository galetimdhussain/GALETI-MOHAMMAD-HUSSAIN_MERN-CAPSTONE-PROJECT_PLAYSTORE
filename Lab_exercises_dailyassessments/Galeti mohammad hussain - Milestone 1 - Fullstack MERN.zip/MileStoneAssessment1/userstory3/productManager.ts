enum CategoryType {
  Electronics = "Electronics",
  Fashion = "Fashion",
  Jewellery = "Jewellery"
}

interface IProduct {
  id: number;
  name: string;
  category: CategoryType;
  price: number; // stored in dollars
  stock: number; 
}

const INR_MULTIPLIER = 100;
const updateLogs: string[] = [];

function toRupees(dollarPrice: number): number {
  return dollarPrice * INR_MULTIPLIER;
}

function trackInventoryUpdate(
  target: object,
  methodName: string,
  descriptor: PropertyDescriptor
): void {
  const originalMethod = descriptor.value as (price: number, stock: number) => void;

  descriptor.value = function (newPrice: number, newStock: number): void {
    const product = this as Product;
    const logLine =
      `Updated ${product.name} | Price: Rs. ${toRupees(product.price).toFixed(2)} -> Rs. ${toRupees(newPrice).toFixed(2)}, ` +
      `Stock: ${product.stock} -> ${newStock}`;

    updateLogs.push(logLine);
    console.log(logLine);
    originalMethod.call(this, newPrice, newStock);
  };
}

class Product implements IProduct {
  id: number;
  name: string;
  category: CategoryType;
  price: number;
  stock: number;

  constructor(
    id: number,
    name: string,
    category: CategoryType,
    price: number,
    stock: number
  ) {
    this.id = id;
    this.name = name;
    this.category = category;
    this.price = price;
    this.stock = stock;
  }

  @trackInventoryUpdate
  updatePriceAndStock(newPrice: number, newStock: number): void {
    this.price = newPrice;
    this.stock = newStock;
  }
}

const inventoryMap: Map<number, Product> = new Map<number, Product>();
const inventoryTuples: [number, string, number][] = [];

inventoryMap.set(
  1,
  new Product(1, "Fjallraven Backpack", CategoryType.Fashion, 109.95, 25)
);
inventoryMap.set(
  2,
  new Product(2, "WD 2TB External Hard Drive", CategoryType.Electronics, 64, 30)
);
inventoryMap.set(
  3,
  new Product(3, "Pierced Owl Rose Gold Plated", CategoryType.Jewellery, 10.99, 40)
);

const selectedProduct: Product | undefined = inventoryMap.get(1);
if (selectedProduct) {
  selectedProduct.updatePriceAndStock(99.95, 20);
}

const secondProduct: Product | undefined = inventoryMap.get(2);
if (secondProduct) {
  secondProduct.updatePriceAndStock(59.5, 27);
}

for (const product of inventoryMap.values()) {
  const tupleItem: [number, string, number] = [product.id, product.name, product.stock];
  inventoryTuples.push(tupleItem);
}

function renderInventoryList(): void {
  const inventoryList = document.getElementById("tsOutput");
  if (!inventoryList) {
    return;
  }

  inventoryList.innerHTML = "";
  for (const product of inventoryMap.values()) {
    const listItem = document.createElement("li");
    listItem.textContent =
      `ID: ${product.id}, Name: ${product.name}, Category: ${product.category}, ` +
      `Price: Rs. ${toRupees(product.price).toFixed(2)}, Stock: ${product.stock}`;
    inventoryList.appendChild(listItem);
  }
}

function renderTupleList(): void {
  const tupleList = document.getElementById("tsTupleOutput");
  if (!tupleList) {
    return;
  }

  tupleList.innerHTML = "";
  for (const tupleData of inventoryTuples) {
    const listItem = document.createElement("li");
    listItem.textContent =
      `(${tupleData[0]}, ${tupleData[1]}, ${tupleData[2]})`;
    tupleList.appendChild(listItem);
  }
}

function renderUpdateLogs(): void {
  const logList = document.getElementById("tsLogOutput");
  if (!logList) {
    return;
  }

  logList.innerHTML = "";
  for (const logLine of updateLogs) {
    const listItem = document.createElement("li");
    listItem.textContent = logLine;
    logList.appendChild(listItem);
  }
}

function renderFallbackText(): void {
  const preNode = document.getElementById("inventoryOutput");
  if (!preNode) {
    return;
  }

  const lines: string[] = [];
  lines.push("Inventory Output (Map + for...of)");

  for (const product of inventoryMap.values()) {
    lines.push(
      `ID: ${product.id}, Name: ${product.name}, Category: ${product.category}, Price: Rs. ${toRupees(product.price).toFixed(2)}, Stock: ${product.stock}`
    );
  }

  lines.push("");
  lines.push("Tuple Summary");
  for (const tupleData of inventoryTuples) {
    lines.push(`(${tupleData[0]}, ${tupleData[1]}, ${tupleData[2]})`);
  }

  lines.push("");
  lines.push("Decorator Logs");
  for (const logLine of updateLogs) {
    lines.push(logLine);
  }

  preNode.textContent = lines.join("\n");
}

function initProductManagerModule(): void {
  renderInventoryList();
  renderTupleList();
  renderUpdateLogs();
  renderFallbackText();
}

if (document.readyState === "loading") {
  document.addEventListener("DOMContentLoaded", initProductManagerModule);
} else {
  initProductManagerModule();
}
