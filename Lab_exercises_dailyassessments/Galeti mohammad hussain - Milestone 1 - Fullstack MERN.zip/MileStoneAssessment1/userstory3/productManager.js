"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var CategoryType;
(function (CategoryType) {
    CategoryType["Electronics"] = "Electronics";
    CategoryType["Fashion"] = "Fashion";
    CategoryType["Jewellery"] = "Jewellery";
})(CategoryType || (CategoryType = {}));
const INR_MULTIPLIER = 100;
const updateLogs = [];
function toRupees(dollarPrice) {
    return dollarPrice * INR_MULTIPLIER;
}
function trackInventoryUpdate(target, methodName, descriptor) {
    const originalMethod = descriptor.value;
    descriptor.value = function (newPrice, newStock) {
        const product = this;
        const logLine = `Updated ${product.name} | Price: Rs. ${toRupees(product.price).toFixed(2)} -> Rs. ${toRupees(newPrice).toFixed(2)}, ` +
            `Stock: ${product.stock} -> ${newStock}`;
        updateLogs.push(logLine);
        console.log(logLine);
        originalMethod.call(this, newPrice, newStock);
    };
}
class Product {
    constructor(id, name, category, price, stock) {
        this.id = id;
        this.name = name;
        this.category = category;
        this.price = price;
        this.stock = stock;
    }
    updatePriceAndStock(newPrice, newStock) {
        this.price = newPrice;
        this.stock = newStock;
    }
}
__decorate([
    trackInventoryUpdate
], Product.prototype, "updatePriceAndStock", null);
const inventoryMap = new Map();
const inventoryTuples = [];
inventoryMap.set(1, new Product(1, "Fjallraven Backpack", CategoryType.Fashion, 109.95, 25));
inventoryMap.set(2, new Product(2, "WD 2TB External Hard Drive", CategoryType.Electronics, 64, 30));
inventoryMap.set(3, new Product(3, "Pierced Owl Rose Gold Plated", CategoryType.Jewellery, 10.99, 40));
const selectedProduct = inventoryMap.get(1);
if (selectedProduct) {
    selectedProduct.updatePriceAndStock(99.95, 20);
}
const secondProduct = inventoryMap.get(2);
if (secondProduct) {
    secondProduct.updatePriceAndStock(59.5, 27);
}
for (const product of inventoryMap.values()) {
    const tupleItem = [product.id, product.name, product.stock];
    inventoryTuples.push(tupleItem);
}
function renderInventoryList() {
    const inventoryList = document.getElementById("tsOutput");
    if (!inventoryList) {
        return;
    }
    inventoryList.innerHTML = "";
    for (const product of inventoryMap.values()) {
        const listItem = document.createElement("li");
        listItem.textContent =
            `ID: ${product.id}, Name: ${product.name}, Category: ${product.category}, ` +
                `Price: Rs. ${toRupees(product.price).toFixed(2)}, Stock: ${product.stock}`;
        inventoryList.appendChild(listItem);
    }
}
function renderTupleList() {
    const tupleList = document.getElementById("tsTupleOutput");
    if (!tupleList) {
        return;
    }
    tupleList.innerHTML = "";
    for (const tupleData of inventoryTuples) {
        const listItem = document.createElement("li");
        listItem.textContent =
            `(${tupleData[0]}, ${tupleData[1]}, ${tupleData[2]})`;
        tupleList.appendChild(listItem);
    }
}
function renderUpdateLogs() {
    const logList = document.getElementById("tsLogOutput");
    if (!logList) {
        return;
    }
    logList.innerHTML = "";
    for (const logLine of updateLogs) {
        const listItem = document.createElement("li");
        listItem.textContent = logLine;
        logList.appendChild(listItem);
    }
}
function renderFallbackText() {
    const preNode = document.getElementById("inventoryOutput");
    if (!preNode) {
        return;
    }
    const lines = [];
    lines.push("Inventory Output (Map + for...of)");
    for (const product of inventoryMap.values()) {
        lines.push(`ID: ${product.id}, Name: ${product.name}, Category: ${product.category}, Price: Rs. ${toRupees(product.price).toFixed(2)}, Stock: ${product.stock}`);
    }
    lines.push("");
    lines.push("Tuple Summary");
    for (const tupleData of inventoryTuples) {
        lines.push(`(${tupleData[0]}, ${tupleData[1]}, ${tupleData[2]})`);
    }
    lines.push("");
    lines.push("Decorator Logs");
    for (const logLine of updateLogs) {
        lines.push(logLine);
    }
    preNode.textContent = lines.join("\n");
}
function initProductManagerModule() {
    renderInventoryList();
    renderTupleList();
    renderUpdateLogs();
    renderFallbackText();
}
if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", initProductManagerModule);
}
else {
    initProductManagerModule();
}
