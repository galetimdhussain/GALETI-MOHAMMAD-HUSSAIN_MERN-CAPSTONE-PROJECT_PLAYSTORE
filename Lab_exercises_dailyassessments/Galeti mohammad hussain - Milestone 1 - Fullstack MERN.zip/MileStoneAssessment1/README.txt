E-Commerce Product Management System
Milestone 1 Assessment - Front-End Development

1. Project Summary
- This project is organized as one assessment with 3 user story folders.
- `userstory1/index.html` is the integrated main page.
- User Story 2 logic is loaded from `userstory2/script.js` and `userstory2/products.json`.
- User Story 3 logic is loaded from `userstory3/productManager.js`.
- A separate Story 3 demo page is available at `userstory3/index.html` for direct checking.

2. Technologies Used
- HTML5
- CSS3
- Bootstrap 5
- JavaScript (ES6)
- Fetch API
- JSON
- TypeScript

3. Current Features Implemented
- User Story 1:
  Semantic structure (`header`, `nav`, `main`, `section`, `footer`), featured product cards, newsletter form validation, carousel, and clean styling.
- User Story 2:
  Fetch with `async/await`, error handling with `try...catch`, loading message, dynamic rendering, category filter, price sort, and rupee display.
- User Story 3:
  `IProduct` interface, `Product` class, method decorator, `Map` storage, tuple array, `for...of` iteration, and UI output rendering.

4. Currency and Images
- Product prices are displayed in rupees in UI (`Rs.`).
- Product listing uses real product image URLs.
- `onerror` fallback image handling is included in product card rendering.

5. Folder Structure
- `userstory1/index.html`: integrated main page
- `userstory1/style.css`: styling for page layout and sections
- `userstory1/no-image.svg`: local fallback image
- `userstory2/index.html`: standalone page for User Story 2
- `userstory2/script.js`: fetch, filter, sort, render, newsletter validation integration
- `userstory2/products.json`: product dataset with image URLs
- `userstory3/index.html`: standalone page for User Story 3 output
- `userstory3/productManager.ts`: TypeScript source
- `userstory3/productManager.js`: compiled JS output
- `userstory3/tsconfig.json`: TypeScript configuration

6. Notes
- Always run from a local server (not direct file open) for JSON fetch to work.
- Compile TypeScript before final run:
  `tsc -p .\userstory3\tsconfig.json`
