const express = require("express");
const courseRouter = require("./routes/courses");

const app = express();
const PORT = 4000;

app.use(express.json());

// Root Route
app.get("/", (req, res) => {
    res.json({ message: "Welcome to SkillSphere LMS API" });
});

// Courses Routes
app.use("/courses", courseRouter);

app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
});