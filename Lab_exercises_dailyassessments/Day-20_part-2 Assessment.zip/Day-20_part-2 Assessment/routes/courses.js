const express = require("express");
const router = express.Router();

// Route-level middleware
function validateCourseId(req, res, next) {
    const id = req.params.id;

    if (!/^\d+$/.test(id)) {
        return res.status(400).json({ error: "Invalid course ID" });
    }

    next();
}

// Dynamic route with middleware
router.get("/:id", validateCourseId, (req, res) => {
    const id = req.params.id;

    res.json({
        id: id,
        name: "React Mastery",
        duration: "6 weeks"
    });
});

module.exports = router;