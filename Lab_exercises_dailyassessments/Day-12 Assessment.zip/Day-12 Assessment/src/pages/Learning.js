import React, { useState, lazy, Suspense } from "react";

const CourseDetails = lazy(() => import("../modules/CourseDetails"));
const InstructorProfile = lazy(() => import("../modules/InstructorProfile"));

function Learning() {

  const [course, setCourse] = useState(false);
  const [instructor, setInstructor] = useState(false);

  return (
    <div className="container mt-4">
      <h2>Learning Modules</h2>

      <button className="btn btn-primary me-2" onClick={() => setCourse(true)}>
        View Details
      </button>

      <button className="btn btn-secondary" onClick={() => setInstructor(true)}>
        Instructor Profile
      </button>

      <Suspense
        fallback={
          <div className="text-center mt-4">
            <div className="spinner-border text-primary"></div>
            <p>Loading...</p>
          </div>
        }
      >
        {course && <CourseDetails />}
        {instructor && <InstructorProfile />}
      </Suspense>
    </div>
  );
}

export default Learning;