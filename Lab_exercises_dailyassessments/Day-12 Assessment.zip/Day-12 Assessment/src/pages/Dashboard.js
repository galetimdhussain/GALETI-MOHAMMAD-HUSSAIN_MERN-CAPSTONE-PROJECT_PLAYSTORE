import React, { useState } from "react";
import StatsCard from "../modules/StatsCard";

function Dashboard() {

  const [data, setData] = useState({
    students: 100,
    courses: 5,
    instructors: 3
  });

  const updateOne = () => {
    setData(prev => ({ ...prev, courses: prev.courses + 1 }));
  };

  return (
    <div className="container mt-4">
      <h2>Dashboard</h2>

      <button className="btn btn-warning mb-3" onClick={updateOne}>
        Simulate Update
      </button>

      <div className="d-flex">
        <StatsCard title="Students" value={data.students}/>
        <StatsCard title="Courses" value={data.courses}/>
        <StatsCard title="Instructors" value={data.instructors}/>
      </div>
    </div>
  );
}

export default Dashboard;