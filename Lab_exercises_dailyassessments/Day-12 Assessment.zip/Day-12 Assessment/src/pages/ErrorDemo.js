import React from "react";
import ErrorBoundary from "../modules/ErrorBoundary";
import BrokenComponent from "../modules/BrokenComponent";
import Modal from "../modules/Modal";

function ErrorDemo() {

  const [open, setOpen] = React.useState(false);

  return (
    <div className="container mt-4">
      <h2>Error Boundary & Portal Demo</h2>

      <button className="btn btn-info mb-3" onClick={() => setOpen(true)}>
        Show Notification
      </button>

      <ErrorBoundary>
        <BrokenComponent />
      </ErrorBoundary>

      <Modal show={open} onClose={() => setOpen(false)}>
        <h4>Notification</h4>
        <p>This modal is rendered using React Portal.</p>
      </Modal>
    </div>
  );
}

export default ErrorDemo;