import React from "react";
import ReactDOM from "react-dom";

function Modal({ show, onClose, children }) {

  if (!show) return null;

  return ReactDOM.createPortal(
    <div className="overlay">
      <div className="modalbox">
        <button className="btn btn-danger mb-2" onClick={onClose}>Close</button>
        {children}
      </div>
    </div>,
    document.getElementById("portal-root")
  );
}

export default Modal;