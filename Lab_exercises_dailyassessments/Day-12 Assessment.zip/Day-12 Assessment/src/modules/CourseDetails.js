import React from "react";

function CourseDetails() {
  return (
    <div className="card p-3 mt-3">
      <h4>Course Details</h4>
      <p>React Advanced Concepts: Lazy loading, error boundaries and optimization.</p>
    </div>
  );
}

export default CourseDetails;