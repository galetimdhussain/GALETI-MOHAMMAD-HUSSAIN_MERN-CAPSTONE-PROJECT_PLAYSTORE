import React from "react";

function BrokenComponent() {
  throw new Error("Crash triggered");
}

export default BrokenComponent;