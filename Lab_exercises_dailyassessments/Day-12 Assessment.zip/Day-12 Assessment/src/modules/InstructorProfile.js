import React from "react";

function InstructorProfile() {
  return (
    <div className="card p-3 mt-3">
      <h4>Instructor</h4>
      <p>Instructor: Sarah Johnson</p>
      <p>Experience: 12 years in Frontend Development</p>
    </div>
  );
}

export default InstructorProfile;