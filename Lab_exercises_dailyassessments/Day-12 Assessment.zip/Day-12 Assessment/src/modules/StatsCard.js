import React from "react";

const StatsCard = React.memo(function StatsCard({ title, value }) {
  console.log(title + " rendered");

  return (
    <div className="card p-3 m-2 text-center">
      <h5>{title}</h5>
      <h2>{value}</h2>
    </div>
  );
});

export default StatsCard;