import React from "react";
import { Routes, Route, Link } from "react-router-dom";
import Learning from "./pages/Learning";
import Dashboard from "./pages/Dashboard";
import ErrorDemo from "./pages/ErrorDemo";

function App() {
  return (
    <div>

      <nav className="navbar navbar-dark bg-black px-6">
        <Link className="navbar-brand" to="/">Hussain's Online Learning</Link>
        <div>
          <Link className="btn btn-outline-light me-2" to="/">Learning</Link>
          <Link className="btn btn-outline-light me-2" to="/dashboard">Dashboard</Link>
          <Link className="btn btn-outline-light" to="/error">Error Demo</Link>
        </div>
      </nav>

      <Routes>
        <Route path="/" element={<Learning />} />
        <Route path="/dashboard" element={<Dashboard />} />
        <Route path="/error" element={<ErrorDemo />} />
      </Routes>

    </div>
  );
}

export default App;