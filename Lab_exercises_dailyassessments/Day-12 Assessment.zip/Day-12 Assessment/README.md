 Online Learning Platform – React Advanced Concepts Demo

 Overview

This project demonstrates several advanced React concepts inside a single page application. The goal was not to build a full learning portal but to clearly show how each React feature works in a practical setting. The application contains learning modules, a dashboard, error handling, and modal notifications, all running in one React app without page reloads.

The focus areas are lazy loading, performance optimization, safe error handling, and rendering UI outside the normal DOM hierarchy.

Approach

I structured the project as a modular React SPA using React Router. Each concept was isolated into a small, understandable component so the behavior can be easily observed and tested.

Instead of mixing everything into one large file, each feature was implemented in its own module and then connected through routing. This makes the application easier to maintain and also demonstrates real world component organization.

The application starts with the Learning page. From there the user can navigate to the Dashboard and the Error Demo page without any browser refresh, which confirms SPA behavior.

Implemented Concepts

### 1. Lazy Loading and Code Splitting

The Course Details and Instructor Profile components are loaded only when the user clicks a button. They are imported using `React.lazy()` and rendered using `Suspense`.

Result:

* Initial bundle loads faster
* Components are downloaded only when needed
* A spinner appears while the component loads

This proves dynamic module loading and code splitting.

### 2. Pure Component Optimization

The dashboard uses a `StatsCard` component wrapped with `React.memo`.

Each card receives props: title and value. The component re-renders only if its props change. A console log shows which card actually re-rendered.

When clicking **Simulate Update**, only the "Courses" card updates while the others stay unchanged. This demonstrates render optimization and avoids unnecessary re-renders.

### 3. Error Boundary

An `ErrorBoundary` class component was created using:

* `getDerivedStateFromError()`
* `componentDidCatch()`

A broken component intentionally throws an error. Instead of crashing the whole application, a friendly message appears and the rest of the UI continues working. The error is also logged in the console.

This shows safe rendering and fault tolerance in React.

### 4. React Portal (Modal Notification)

A modal notification is rendered using `ReactDOM.createPortal()` into a separate DOM node (`portal-root`) outside the main root element.

The modal appears above all UI layers and can be opened and closed using parent state. A fade animation is applied using CSS.

This demonstrates how overlays and popups are implemented in real applications.

## SPA Behavior and Data Flow

The application uses React Router for navigation. Moving between pages does not reload the browser. Only the required components update.

Flow of interaction:

1. User clicks a navigation link
2. Router updates the view
3. Only the required component renders
4. Previously loaded state remains intact

This confirms proper single page application behavior.

## Folder Structure

```
src/
  pages/
    Learning.js
    Dashboard.js
    ErrorDemo.js
  modules/
    CourseDetails.js
    InstructorProfile.js
    StatsCard.js
    ErrorBoundary.js
    BrokenComponent.js
    Modal.js
  App.js
  index.js
  App.css
```

## How to Run

1. Install dependencies

```
npm install
```

2. Start the application

```
npm start
```

3. Open in browser

```
http://localhost:3000
```

## How to Test Features

* Learning page: click View Details and Instructor Profile to see lazy loading
* Dashboard: click Simulate Update and check console logs for optimized rendering
* Error Demo: observe friendly error message instead of crash
* Notification button: modal appears above all content

## Notes

This project focuses on demonstrating React behavior rather than UI design. Styling is minimal and kept simple so the logic remains clear. The application is intentionally small but each feature is functional and observable.

The implementation proves that advanced React concepts can be combined inside one SPA while keeping components independent and reusable.
