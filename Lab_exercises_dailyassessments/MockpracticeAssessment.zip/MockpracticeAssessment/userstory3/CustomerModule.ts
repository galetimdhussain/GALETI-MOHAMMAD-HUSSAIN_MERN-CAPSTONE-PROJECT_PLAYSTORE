// Enum for Membership Type
enum MembershipType {
    Regular = "Regular",
    Premium = "Premium",
    VIP = "VIP"
}

// Tuple for Contact Info (Email, Phone)
type ContactInfo = [string, string];

// Interface for Customer
interface ICustomer {
    id: number;
    name: string;
    membership: MembershipType;
    contact: ContactInfo;
    displayDetails(): string;
}

// Decorator to log class creation
function LogCreation(constructor: Function) {
    console.log(`Class ${constructor.name} is created.`);
}

@LogCreation
class Customer implements ICustomer {

    public id: number;
    public name: string;
    public membership: MembershipType;
    public contact: ContactInfo;

    constructor(id: number, name: string, membership: MembershipType, contact: ContactInfo) {
        this.id = id;
        this.name = name;
        this.membership = membership;
        this.contact = contact;
    }

    displayDetails(): string {
        const [email, phone] = this.contact;
        return `Customer ID: ${this.id}
Name: ${this.name}
Membership: ${this.membership}
Email: ${email}
Phone: ${phone}`;
    }
}

// Iterator Class for Customer Collection
class CustomerCollection {
    private customers: Customer[] = [];

    addCustomer(customer: Customer): void {
        this.customers.push(customer);
    }

    *[Symbol.iterator]() {
        for (const customer of this.customers) {
            yield customer;
        }
    }
}

// Sample Usage
const customer1 = new Customer(
    1,
    "Rahul Sharma",
    MembershipType.Premium,
    ["rahul@email.com", "9876543210"]
);

const customer2 = new Customer(
    2,
    "Anita Verma",
    MembershipType.VIP,
    ["anita@email.com", "9123456780"]
);

const collection = new CustomerCollection();
collection.addCustomer(customer1);
collection.addCustomer(customer2);

for (const customer of collection) {
    console.log(customer.displayDetails());
}     npx tsc MockpracticeAssessment/userstory3/CustomerModule.ts