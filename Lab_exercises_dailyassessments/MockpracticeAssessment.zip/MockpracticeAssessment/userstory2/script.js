const eventContainer = document.getElementById("eventContainer");
const categoryFilter = document.getElementById("categoryFilter");
const dateFilter = document.getElementById("dateFilter");

let eventsData = [];

const fetchEvents = async () => {
    try {
        const response = await fetch("events.json");

        if (!response.ok) {
            throw new Error("Failed to fetch events data");
        }

        const data = await response.json();
        eventsData = data;
        renderEvents(eventsData);

    } catch (error) {
        eventContainer.innerHTML = `<p style="color:red;">${error.message}</p>`;
    }
};

const renderEvents = (events) => {
    eventContainer.innerHTML = "";

    events.forEach(event => {
        const { title, category, date, description } = event;

        const card = document.createElement("div");
        card.className = "card";

        card.innerHTML = `
            <h4>${title}</h4>
            <p><strong>Category:</strong> ${category}</p>
            <p><strong>Date:</strong> ${date}</p>
            <p>${description}</p>
        `;

        eventContainer.appendChild(card);
    });
};

const applyFilters = () => {
    const selectedCategory = categoryFilter.value;
    const selectedDate = dateFilter.value;

    let filteredEvents = eventsData;

    if (selectedCategory !== "All") {
        filteredEvents = filteredEvents.filter(
            event => event.category === selectedCategory
        );
    }

    if (selectedDate) {
        filteredEvents = filteredEvents.filter(
            event => event.date === selectedDate
        );
    }

    renderEvents(filteredEvents);
};

categoryFilter.addEventListener("change", applyFilters);
dateFilter.addEventListener("change", applyFilters);

fetchEvents();