use BookVerseDB

db.books.find({ genre: "Fantasy" }).explain("executionStats")

db.books.createIndex({ genre: 1 })
db.books.createIndex({ authorId: 1 })
db.books.createIndex({ "ratings.score": 1 })

db.books.getIndexes()

db.books.find({ genre: "Fantasy" }).explain("executionStats")

db.books.dropIndex({ authorId: 1 })

db.books.getIndexes()

db.books.aggregate([
{ $unwind: "$ratings" },
{ $group: { _id: "$title", avgRating: { $avg: "$ratings.score" } } }
])

db.books.aggregate([
{ $unwind: "$ratings" },
{ $group: { _id: "$title", avgRating: { $avg: "$ratings.score" } } },
{ $sort: { avgRating: -1 } },
{ $limit: 3 }
])

db.books.aggregate([
{ $group: { _id: "$genre", totalBooks: { $sum: 1 } } }
])

db.books.aggregate([
{ $group: { _id: "$authorId", bookCount: { $sum: 1 } } },
{ $match: { bookCount: { $gt: 2 } } }
])

db.books.aggregate([
{ $unwind: "$ratings" },
{ $group: { _id: "$authorId", totalPoints: { $sum: "$ratings.score" } } }
])

db.books.createIndex({ genre: 1, publicationYear: -1 })


db.books.find({ genre: "Fantasy" }).sort({ publicationYear: -1 }).explain("executionStats")



db.books.aggregate([
{ $unwind: "$ratings" },
{
  $group: {
    _id: "$authorId",
    avgScore: { $avg: "$ratings.score" }
  }
},
{ $sort: { avgScore: -1 } },
{ $limit: 1 },
{
  $lookup: {
    from: "authors",
    localField: "_id",
    foreignField: "_id",
    as: "author"
  }
},
{ $unwind: "$author" },
{
  $project: {
    _id: 0,
    authorName: "$author.name",
    avgScore: 1
  }
}
])