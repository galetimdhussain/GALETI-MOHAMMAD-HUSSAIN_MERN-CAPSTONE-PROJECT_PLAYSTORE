const fs = require("fs");

console.log("Reading file...");

fs.readFile("data.txt", "utf8", (err, data) => {

    if (err) {
        console.error("Error reading file:", err);
        return;
    }

    console.log("File Content:");
    console.log(data);

    // Bonus: Intentional delay before confirmation
    setTimeout(() => {
        console.log("Read operation completed");
    }, 2000);

});

console.log("This line runs before file is read (Non-blocking)");