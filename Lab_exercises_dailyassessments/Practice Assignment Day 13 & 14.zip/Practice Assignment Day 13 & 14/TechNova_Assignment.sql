-- I have added query outcomes/outputs below the respected query itself in the comments...
DROP DATABASE IF EXISTS TechNovaDB;
CREATE DATABASE TechNovaDB;
USE TechNovaDB;
CREATE TABLE Department(
    DeptID INT PRIMARY KEY,
    DeptName VARCHAR(50) UNIQUE NOT NULL,
    Location VARCHAR(50) NOT NULL
);
CREATE TABLE Employee(
    EmpID INT PRIMARY KEY,
    EmpName VARCHAR(60) NOT NULL,
    Gender CHAR(1) CHECK (Gender IN ('M','F')),
    DOB DATE NOT NULL,
    HireDate DATE NOT NULL,
    DeptID INT,
    FOREIGN KEY (DeptID) REFERENCES Department(DeptID)
);
CREATE TABLE Project(
    ProjectID INT PRIMARY KEY,
    ProjectName VARCHAR(60) NOT NULL,
    DeptID INT,
    StartDate DATE,
    EndDate DATE,
    FOREIGN KEY (DeptID) REFERENCES Department(DeptID)
);
CREATE TABLE Performance(
    EmpID INT,
    ProjectID INT,
    Rating DECIMAL(3,1),
    ReviewDate DATE,
    PRIMARY KEY (EmpID, ProjectID),
    FOREIGN KEY (EmpID) REFERENCES Employee(EmpID),
    FOREIGN KEY (ProjectID) REFERENCES Project(ProjectID)
);
CREATE TABLE Reward(
    EmpID INT,
    RewardMonth DATE,
    RewardAmount DECIMAL(10,2),
    PRIMARY KEY (EmpID, RewardMonth),
    FOREIGN KEY (EmpID) REFERENCES Employee(EmpID)
);
CREATE INDEX idx_empname ON Employee(EmpName);
CREATE INDEX idx_empdept ON Employee(DeptID);

INSERT INTO Department VALUES
(101,'IT','Bangalore'),
(102,'HR','Delhi'),
(103,'Finance','Mumbai'),
(104,'Sales','Chennai'),
(105,'Support','Hyderabad');

INSERT INTO Employee VALUES
(1,'Asha','F','1990-07-12','2018-06-10',101),
(2,'Raj','M','1988-04-09','2020-03-22',102),
(3,'Neha','F','1995-01-15','2021-08-05',101),
(4,'Vikram','M','1992-11-25','2019-09-12',103),
(5,'Priya','F','1996-02-18','2022-01-20',104);

INSERT INTO Project VALUES
(201,'Payroll System',101,'2023-01-01','2023-06-01'),
(202,'Recruitment Portal',102,'2023-02-01','2023-07-01'),
(203,'Finance Tracker',103,'2023-03-01','2023-08-01'),
(204,'CRM System',104,'2023-04-01','2023-09-01'),
(205,'Helpdesk App',105,'2023-05-01','2023-10-01');

INSERT INTO Performance VALUES
(1,201,4.5,'2023-06-10'),
(2,202,4.0,'2023-07-10'),
(3,201,4.8,'2023-08-10'),
(4,203,3.9,'2023-09-10'),
(5,204,4.7,'2023-10-10');

INSERT INTO Reward VALUES
(1,'2023-01-01',2500),
(2,'2023-02-01',1500),
(3,'2023-03-01',3000),
(4,'2023-04-01',800),
(5,'2023-05-01',2200);

UPDATE Employee
SET DeptID = 105
WHERE EmpID = 5;
SET SQL_SAFE_UPDATES = 0;

DELETE FROM Reward
WHERE RewardAmount <= 1000;
SET SQL_SAFE_UPDATES = 1;
-- Employees joined after 2019
SELECT *
FROM Employee
WHERE HireDate > '2019-01-01';

/* query solution
	EmpID	EmpName	Gender	DOB	HireDate	DeptID
	2	Raj	M	1988-04-09	2020-03-22	102
	3	Neha	F	1995-01-15	2021-08-05	101
	4	Vikram	M	1992-11-25	2019-09-12	103
	5	Priya	F	1996-02-18	2022-01-20	105
						
*/

-- Average rating per department
SELECT d.DeptName, AVG(p.Rating) AS AvgRating
FROM Department d
JOIN Employee e ON d.DeptID = e.DeptID
JOIN Performance p ON e.EmpID = p.EmpID
GROUP BY d.DeptName;
/*
DeptName  AvgRating
Finance	3.90000
HR	4.00000
IT	4.65000
Support	4.70000
*/

-- Employee age
SELECT EmpName,
TIMESTAMPDIFF(YEAR, DOB, CURDATE()) AS Age
FROM Employee;
/*
EmpName  Age
Asha	35
Raj	37
Neha	31
Vikram	33
Priya	30
*/
-- Total rewards this year
SELECT SUM(RewardAmount) AS TotalReward
FROM Reward
WHERE YEAR(RewardMonth) = 2023;

/*
TotalReward
 9200.00
*/


-- Employees reward > 2000
SELECT e.EmpName, r.RewardAmount
FROM Employee e
JOIN Reward r ON e.EmpID = r.EmpID
WHERE r.RewardAmount > 2000;

/*
EmpName   RewardAmount
Asha	2500.00
Neha	3000.00
Priya	2200.00
*/
-- user story-4 = 1 Employee + Department + Project + Rating
SELECT e.EmpName, d.DeptName, pr.ProjectName, p.Rating
FROM Employee e
JOIN Department d ON e.DeptID = d.DeptID
JOIN Performance p ON e.EmpID = p.EmpID
JOIN Project pr ON p.ProjectID = pr.ProjectID;

/*
EmpName DeptName ProjectName  Rating
Asha	IT	Payroll System	4.5
Raj	HR	Recruitment Portal	4.0
Neha	IT	Payroll System	4.8
Vikram	Finance	Finance Tracker	3.9
Priya	Support	CRM System	4.7
*/

-- Highest rated employee per department
SELECT e.EmpName, d.DeptName, p.Rating
FROM Employee e
JOIN Department d ON e.DeptID = d.DeptID
JOIN Performance p ON e.EmpID = p.EmpID
WHERE p.Rating = (
    SELECT MAX(p2.Rating)
    FROM Performance p2
    JOIN Employee e2 ON p2.EmpID = e2.EmpID
    WHERE e2.DeptID = e.DeptID
);

/*
EmpName DeptName Rating
Raj	HR	4.0
Neha	IT	4.8
Vikram	Finance	3.9
Priya	Support	4.7
*/

-- Employees with no rewards
SELECT EmpName
FROM Employee
WHERE EmpID NOT IN (
    SELECT EmpID FROM Reward
);

/*
EmpName
Vikram
*/

-- USER STORY 5 — TCL
START TRANSACTION;

INSERT INTO Employee VALUES
(6,'Kiran','M','1994-03-15','2024-01-10',101);

INSERT INTO Performance VALUES
(6,201,4.2,'2024-02-01');

-- if everything ok
COMMIT;


EXPLAIN
SELECT e.EmpName, d.DeptName, p.Rating
FROM Employee e
JOIN Department d ON e.DeptID=d.DeptID
JOIN Performance p ON e.EmpID=p.EmpID;

/*
id Select_type  table  partitions  type  possible_keys  key key_len ref   rows  filtered  extra 
1	SIMPLE	e		ALL	PRIMARY,idx_empdept				6	100.00	Using where
1	SIMPLE	d		eq_ref	PRIMARY	PRIMARY	4	technovadb.e.DeptID	1	100.00	
1	SIMPLE	p		ref	PRIMARY	PRIMARY	4	technovadb.e.EmpID	1	100.00	
*/


CREATE INDEX idx_perf_emp ON Performance(EmpID);

EXPLAIN
SELECT e.EmpName, d.DeptName, p.Rating
FROM Employee e
JOIN Department d ON e.DeptID=d.DeptID
JOIN Performance p ON e.EmpID=p.EmpID;

/*
id Select_type  table  partitions  type  possible_keys  key key_len ref   rows  filtered  extra
1	SIMPLE	e		ALL	PRIMARY,idx_empdept				6	100.00	Using where
1	SIMPLE	d		eq_ref	PRIMARY	PRIMARY	4	technovadb.e.DeptID	1	100.00	
1	SIMPLE	p		ref	PRIMARY,idx_perf_emp	idx_perf_emp	4	technovadb.e.EmpID	1	100.00	
*/
CREATE VIEW EmployeePerformanceView AS
SELECT e.EmpName, d.DeptName, p.Rating
FROM Employee e
JOIN Department d ON e.DeptID=d.DeptID
JOIN Performance p ON e.EmpID=p.EmpID;

SELECT * FROM EmployeePerformanceView;
/*
EmpName  DeptName  Rating
Asha	IT	4.5
Raj	HR	4.0
Neha	IT	4.8
Vikram	Finance	3.9
Priya	Support	4.7
Kiran	IT	4.2
*/

DELIMITER $$

CREATE PROCEDURE GetTopPerformers(IN dept VARCHAR(50))
BEGIN
    SELECT e.EmpName, p.Rating
    FROM Employee e
    JOIN Department d ON e.DeptID=d.DeptID
    JOIN Performance p ON e.EmpID=p.EmpID
    WHERE d.DeptName = dept
    ORDER BY p.Rating DESC
    LIMIT 3;
END $$

DELIMITER ;


CALL GetTopPerformers('IT');

/*
EmpName  Rating
Neha	4.8
Asha	4.5
Kiran	4.2
*/