// 2. Implement Class
var ContactManager = /** @class */ (function () {
    function ContactManager() {
        this.contacts = [];
    }
    // Add Contact
    ContactManager.prototype.addContact = function (contact) {
        var exists = this.contacts.find(function (c) { return c.id === contact.id; });
        if (exists) {
            console.log("Error: Contact with ID ".concat(contact.id, " already exists."));
            return;
        }
        this.contacts.push(contact);
        console.log("Success: Contact with ID ".concat(contact.id, " added successfully."));
    };
    // View Contacts
    ContactManager.prototype.viewContacts = function () {
        if (this.contacts.length === 0) {
            console.log("No contacts available.");
        }
        return this.contacts;
    };
    // Modify Contact
    ContactManager.prototype.modifyContact = function (id, updatedContact) {
        var contact = this.contacts.find(function (c) { return c.id === id; });
        if (!contact) {
            console.log("Error: Contact with ID ".concat(id, " does not exist."));
            return;
        }
        Object.assign(contact, updatedContact);
        console.log("Success: Contact with ID ".concat(id, " modified successfully."));
    };
    // Delete Contact
    ContactManager.prototype.deleteContact = function (id) {
        var index = this.contacts.findIndex(function (c) { return c.id === id; });
        if (index === -1) {
            console.log("Error: Contact with ID ".concat(id, " does not exist."));
            return;
        }
        this.contacts.splice(index, 1);
        console.log("Success: Contact with ID ".concat(id, " deleted successfully."));
    };
    return ContactManager;
}());
// 4. Testing Script
var manager = new ContactManager();
// Add Contacts
manager.addContact({ id: 1, name: "Rahul Sharma", email: "rahul@email.com", phone: "9876543210" });
manager.addContact({ id: 2, name: "Anita Verma", email: "anita@email.com", phone: "9123456780" });
manager.addContact({ id: 3, name: "Suresh Kumar", email: "rahim@gmail.com", phone: "9988776655" });
// View Contacts
console.log("All Contacts:");
console.log(manager.viewContacts());
manager.modifyContact(1, { email: "rahul.new@email.com" });
console.log("After Modification:");
console.log(manager.viewContacts());
// Delete Contact
manager.deleteContact(2);
// View After Deletion
console.log("After Deletion:");
console.log(manager.viewContacts());
// Attempt to Modify Non-Existing Contact
manager.modifyContact(5, { name: "Unknown" });
// Attempt to Delete Non-Existing Contact
manager.deleteContact(5);
