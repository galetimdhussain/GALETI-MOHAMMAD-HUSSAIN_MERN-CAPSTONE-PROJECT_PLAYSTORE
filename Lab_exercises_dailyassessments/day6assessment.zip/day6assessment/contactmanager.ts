// 1. Define Interface
interface Contact {
    id: number;
    name: string;
    email: string;
    phone: string;
}

// 2. Implement Class
class ContactManager {

    private contacts: Contact[] = [];

    // Add Contact
    addContact(contact: Contact): void {
        const exists = this.contacts.find(c => c.id === contact.id);

        if (exists) {
            console.log(`Error: Contact with ID ${contact.id} already exists.`);
            return;
        }

        this.contacts.push(contact);
        console.log(`Success: Contact with ID ${contact.id} added successfully.`);
    }

    // View Contacts
    viewContacts(): Contact[] {
        if (this.contacts.length === 0) {
            console.log("No contacts available.");
        }
        return this.contacts;
    }

    // Modify Contact
    modifyContact(id: number, updatedContact: Partial<Contact>): void {
        const contact = this.contacts.find(c => c.id === id);

        if (!contact) {
            console.log(`Error: Contact with ID ${id} does not exist.`);
            return;
        }

        Object.assign(contact, updatedContact);
        console.log(`Success: Contact with ID ${id} modified successfully.`);
    }

    // Delete Contact
    deleteContact(id: number): void {
        const index = this.contacts.findIndex(c => c.id === id);

        if (index === -1) {
            console.log(`Error: Contact with ID ${id} does not exist.`);
            return;
        }

        this.contacts.splice(index, 1);
        console.log(`Success: Contact with ID ${id} deleted successfully.`);
    }
}

// 4. Testing Script
const manager = new ContactManager();

// Add Contacts
manager.addContact({ id: 1, name: "Rahul Sharma", email: "rahul@email.com", phone: "9876543210" });
manager.addContact({ id: 2, name: "Anita Verma", email: "anita@email.com", phone: "9123456780" });
manager.addContact({ id: 3, name: "Suresh Kumar", email: "rahim@gmail.com", phone: "9988776655" });

// View Contacts
console.log("All Contacts:");
console.log(manager.viewContacts());


manager.modifyContact(1, { email: "rahul.new@email.com" });


console.log("After Modification:");
console.log(manager.viewContacts());

// Delete Contact
manager.deleteContact(2);

// View After Deletion
console.log("After Deletion:");
console.log(manager.viewContacts());

// Attempt to Modify Non-Existing Contact
manager.modifyContact(5, { name: "Unknown" });

// Attempt to Delete Non-Existing Contact
manager.deleteContact(5);